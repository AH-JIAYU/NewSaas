import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-FT8GUwQM.js";import"./dictionary-cUL4vIet.js";import"./index-vhbio0rd.js";export{o as default};
