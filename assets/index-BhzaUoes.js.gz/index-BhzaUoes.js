import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CrcPyTPH.js";import"./user_supplier-CX2Fdfrt.js";import"./index-DnLPxmbI.js";export{o as default};
