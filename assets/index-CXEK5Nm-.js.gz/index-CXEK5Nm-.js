import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ix0OSgbo.js";import"./survey_vip-h_0Eo3LB.js";import"./index--gIewHn0.js";export{o as default};
