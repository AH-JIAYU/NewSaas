import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DeTIn9mr.js";import"./dictionary-D_WcnURx.js";import"./index-BTcEBOVJ.js";export{o as default};
