import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DHSZpMky.js";import"./project_settlement-Bkw74FhR.js";import"./index-D9IZPIam.js";export{o as default};
