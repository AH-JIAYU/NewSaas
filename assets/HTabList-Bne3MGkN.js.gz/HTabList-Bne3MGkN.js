import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CjfgChVb.js";import"./index-P8dMXWZ8.js";import"./use-resolve-button-type-CX21IITv.js";export{o as default};
