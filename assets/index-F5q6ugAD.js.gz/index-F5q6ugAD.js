import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BbIBFNAx.js";import"./projectManagement-YeQqdV-_.js";import"./index-Bn1vWZLk.js";export{o as default};
