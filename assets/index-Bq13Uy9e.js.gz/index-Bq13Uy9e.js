import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BhwKq0G6.js";import"./dictionary-Bgb7h1xi.js";import"./index-DtqcPD5G.js";export{o as default};
