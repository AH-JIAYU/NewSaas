import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bd37W-cF.js";import"./index-BTA1u_t0.js";import"./role-VUcGfh4S.js";export{o as default};
