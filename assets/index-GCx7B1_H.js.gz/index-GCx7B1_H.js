import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DM6b3W43.js";import"./index--d-k_wOm.js";/* empty css                      */export{o as default};
