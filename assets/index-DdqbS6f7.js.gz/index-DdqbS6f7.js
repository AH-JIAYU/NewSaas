import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D9FLJK74.js";import"./index-C5gylVSa.js";/* empty css                      */export{o as default};
