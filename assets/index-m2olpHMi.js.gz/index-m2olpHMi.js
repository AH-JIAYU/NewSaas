import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CK0booKo.js";import"./user_customer-z1invb7t.js";import"./index-Dmg9F5Q1.js";import"./apiLoading-CacYAXPU.js";export{o as default};
