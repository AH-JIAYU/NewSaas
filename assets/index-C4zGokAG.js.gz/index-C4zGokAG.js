import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DNdC6ueD.js";import"./dictionary-Cfwy9KpP.js";import"./index-eqTpju21.js";export{o as default};
