import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CfkQjuh3.js";import"./index-CWgqmEzW.js";/* empty css                      */export{o as default};
