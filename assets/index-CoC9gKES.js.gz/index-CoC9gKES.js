import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DbR_SW-E.js";import"./dictionary-B_nFfofu.js";import"./index-DkA26UQR.js";export{o as default};
