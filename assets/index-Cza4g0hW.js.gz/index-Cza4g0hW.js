import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D10stPT2.js";import"./projectManagement-bh5OvUoq.js";import"./index-DZCXLDVM.js";export{o as default};
