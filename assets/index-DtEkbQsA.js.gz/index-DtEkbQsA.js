import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1f2X5GS.js";import"./dictionary-CW9gBXrA.js";import"./index-FnfKA9mU.js";export{o as default};
