import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BCjVa_Kh.js";import"./index-BSVPXFpA.js";import"./use-resolve-button-type-C4L_l0WX.js";export{o as default};
