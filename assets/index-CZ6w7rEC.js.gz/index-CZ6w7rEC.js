import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DogE8bVX.js";import"./dictionary-BagSnd9P.js";import"./index-1QIZv5TL.js";export{o as default};
