import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CxrWW2cv.js";import"./index-DJn7V0Dv.js";export{m as default};
