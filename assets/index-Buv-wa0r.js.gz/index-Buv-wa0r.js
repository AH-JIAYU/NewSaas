import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DjC4QSUe.js";import"./position_manage-Di8AxlvS.js";import"./index-B9wLryVD.js";export{o as default};
