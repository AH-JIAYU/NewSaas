import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DB2oEwKc.js";import"./index-Dr8SQZX-.js";import"./use-resolve-button-type-Brz_CxuN.js";export{o as default};
