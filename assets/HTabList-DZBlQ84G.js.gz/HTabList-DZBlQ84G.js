import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-C9BwxFYj.js";import"./index-BP3NysZD.js";import"./use-resolve-button-type-CNj_3j1s.js";export{o as default};
