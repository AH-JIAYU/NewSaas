import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D60PT-U3.js";import"./index-LooN7LAT.js";import"./role-Dtm9gzEe.js";export{o as default};
