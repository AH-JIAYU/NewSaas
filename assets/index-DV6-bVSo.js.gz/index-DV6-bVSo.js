import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DF4bkFyV.js";import"./project_settlement-Ol2fyLDq.js";import"./index-BEO6Civ3.js";export{o as default};
