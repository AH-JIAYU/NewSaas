import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B_OKGtKZ.js";import"./apiLoading-BLzlkHqy.js";import"./index-BBgVRxyN.js";import"./user_customer-CqaooCEg.js";export{o as default};
