import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Si30Dane.js";import"./survey_vip-D5cfj1N9.js";import"./index-Bz0tbEGt.js";export{o as default};
