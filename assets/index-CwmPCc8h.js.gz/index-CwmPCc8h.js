import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CgBnLo6a.js";import"./dictionary-5C2A3ilW.js";import"./index-BooDzcUr.js";export{o as default};
