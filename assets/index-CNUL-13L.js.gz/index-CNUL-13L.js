import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DWI-tFTC.js";import"./dictionary-v-_V13VC.js";import"./index-mRC44AUX.js";export{o as default};
