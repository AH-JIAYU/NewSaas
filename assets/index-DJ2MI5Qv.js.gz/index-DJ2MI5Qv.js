import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_1U3Txt.js";import"./projectManagement-C8n0v24p.js";import"./index-D17MTJ4o.js";export{o as default};
