import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DbrpUHZs.js";import"./project_settlement-DRtl2AfU.js";import"./index-SEhFNywK.js";export{o as default};
