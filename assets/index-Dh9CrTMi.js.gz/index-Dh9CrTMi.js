import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BmoN7MaZ.js";import"./apiLoading-CRCI9HBw.js";import"./index-ClXpGrc7.js";import"./user_customer-DoBLqZ1p.js";export{o as default};
