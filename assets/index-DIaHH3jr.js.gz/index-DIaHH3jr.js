import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D4w1lGsg.js";import"./dictionary-COWWBbt9.js";import"./index-BrOEW0VG.js";export{o as default};
