import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BMcBq82o.js";import"./dictionary-pofI4f_G.js";import"./index-Deny_hqO.js";export{o as default};
