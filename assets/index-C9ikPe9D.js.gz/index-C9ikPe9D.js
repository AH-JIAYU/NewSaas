import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CxjSX3-V.js";import"./dictionary-D5bv1BOC.js";import"./index-CCiB9AnP.js";export{o as default};
