import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BUq897i4.js";import"./projectManagement-CPYMXzmQ.js";import"./index-8rKJscCT.js";export{o as default};
