import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3ZOmYD1.js";import"./user_cooperation-COCWkMpu.js";import"./index-neAswt5j.js";export{o as default};
