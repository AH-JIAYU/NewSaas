import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CwCpDbYB.js";import"./dictionary-DFM2lrNU.js";import"./index-oxkd8Woh.js";export{o as default};
