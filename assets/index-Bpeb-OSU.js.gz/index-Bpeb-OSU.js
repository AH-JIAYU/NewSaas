import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BwUQW4Kb.js";import"./index-CSh8ixW9.js";import"./index-896nYoNp.js";export{o as default};
