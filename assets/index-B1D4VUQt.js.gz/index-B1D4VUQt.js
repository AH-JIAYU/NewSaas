import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BtOAAuT8.js";import"./apiLoading-C7u4rbg_.js";import"./index-m0_ZzCtf.js";import"./user_customer-3gjD51o0.js";export{o as default};
