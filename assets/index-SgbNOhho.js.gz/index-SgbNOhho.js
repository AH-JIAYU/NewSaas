import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-LaNgW9mL.js";import"./dictionary-kVpbk8US.js";import"./index-l5RNFs2b.js";export{o as default};
