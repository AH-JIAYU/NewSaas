import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CNE8sk7Z.js";import"./survey_vip-DgA5i4Xq.js";import"./index-CLQFNkLK.js";export{o as default};
