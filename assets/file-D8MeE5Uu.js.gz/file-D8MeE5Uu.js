import{k as t}from"./index-Cs2Vk5-P.js";const o={upload:e=>t.post("project/uploadQiniu",e),detail:e=>t.post("project/getQiniuFileUrl",e),delete:e=>t.post("project/deleteQiniu",e)};export{o as f};
