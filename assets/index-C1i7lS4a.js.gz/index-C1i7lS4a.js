import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-SF5lEXfs.js";import"./dictionary-Bl1F9_6m.js";import"./index-CYKxYhEx.js";export{o as default};
