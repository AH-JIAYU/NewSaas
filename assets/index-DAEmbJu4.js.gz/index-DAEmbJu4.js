import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BXVPQPHc.js";import"./user_customer-BjUaLOgW.js";import"./index-BrM9WDxg.js";import"./apiLoading-DCHlD0y8.js";export{o as default};
