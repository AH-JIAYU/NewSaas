import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BVWkJwj7.js";import"./dictionary-C1LXFTZv.js";import"./index-CMNRXjnW.js";export{o as default};
