import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-a7V-d14s.js";import"./index-fuY6ctZR.js";import"./role-i3sPE67G.js";export{o as default};
