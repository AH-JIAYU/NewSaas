import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DaJYrcoC.js";import"./index-CWtp1ebv.js";export{m as default};
