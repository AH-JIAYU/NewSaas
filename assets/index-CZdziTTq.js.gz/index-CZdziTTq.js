import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DCvq4n_1.js";import"./dictionary-B7UJlynE.js";import"./index-CyYYGH_S.js";export{o as default};
