import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BegNjqOv.js";import"./index-BMiaO8YQ.js";import"./use-resolve-button-type-C8Ek9Bvv.js";export{o as default};
