import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DFHmbe-Z.js";import"./project_settlement-Zw5xEHUh.js";import"./index-CSh8ixW9.js";export{o as default};
