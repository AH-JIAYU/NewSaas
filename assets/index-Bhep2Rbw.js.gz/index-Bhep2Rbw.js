import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CPNuv36P.js";import"./index-CzARc10T.js";/* empty css                      */export{o as default};
