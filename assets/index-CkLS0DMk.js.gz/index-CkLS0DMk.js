import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BamyrGcy.js";import"./index-BOglyGfo.js";export{m as default};
