import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-OPnI2juv.js";import"./dictionary-DEYIJM0w.js";import"./index-Q_OhXZcn.js";export{o as default};
