import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CEoscP_6.js";import"./index-CuUOayzI.js";import"./index-dvAgep4p.js";import"./department-Fgy5Yzha.js";export{o as default};
