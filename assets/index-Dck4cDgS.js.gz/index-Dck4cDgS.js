import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ECJLpdes.js";import"./dictionary-Cl8CpJwG.js";import"./index-BIEAW5nC.js";export{o as default};
