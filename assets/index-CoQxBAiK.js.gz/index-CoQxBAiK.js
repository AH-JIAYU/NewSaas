import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B9IoK_1c.js";import"./dictionary-CTqYkHfP.js";import"./index-0ArysPfv.js";export{o as default};
