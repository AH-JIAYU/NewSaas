import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BQX9w4Hl.js";import"./project_settlement-B4xjihIB.js";import"./index-CCiB9AnP.js";export{o as default};
