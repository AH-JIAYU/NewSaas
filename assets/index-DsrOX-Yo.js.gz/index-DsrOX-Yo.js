import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bx3LFvRv.js";import"./index-DkNEDn86.js";import"./index-VLp8k4vq.js";import"./department-BdPMGWiz.js";export{o as default};
