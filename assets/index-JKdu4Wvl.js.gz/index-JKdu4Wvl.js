import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BFFaSQIC.js";import"./dictionary-ylVUrfPq.js";import"./index-QlJSmmx7.js";export{o as default};
