import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-3mUD4p0o.js";import"./finance_invoice-CCjSshbC.js";import"./index-CHTO5iG0.js";export{o as default};
