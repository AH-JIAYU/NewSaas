import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-WfA5VEQh.js";import"./dictionary-CPOC-OMN.js";import"./index-CRiLI5We.js";export{o as default};
