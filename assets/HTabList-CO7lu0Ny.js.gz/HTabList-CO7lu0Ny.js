import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Df3e-0FX.js";import"./index-ynKxKXgj.js";import"./use-resolve-button-type-CrbAihbY.js";export{o as default};
