import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CjKuFzuJ.js";import"./dictionary-D_u9adNY.js";import"./index-o59bYei-.js";export{o as default};
