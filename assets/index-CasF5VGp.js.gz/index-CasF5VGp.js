import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CiVWLdOS.js";import"./dictionary-Ds9fgIuo.js";import"./index-CxSXUQRU.js";export{o as default};
