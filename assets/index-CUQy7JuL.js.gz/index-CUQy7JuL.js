import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DT7coBeL.js";import"./otherFunctions_screenLibrary-Do2wQC2R.js";import"./index-JVwiYWif.js";export{o as default};
