import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-3FXJojyu.js";import"./index-CIpj5PiF.js";import"./use-resolve-button-type-DvXpZ5oI.js";export{o as default};
