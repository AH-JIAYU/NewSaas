import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BvsiSlwW.js";import"./index-BgFpqt2S.js";import"./use-resolve-button-type-X8lgclj3.js";export{o as default};
