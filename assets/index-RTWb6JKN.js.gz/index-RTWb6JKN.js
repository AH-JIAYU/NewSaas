import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Df5G_2Rq.js";import"./dictionary-BpsekY7y.js";import"./index-puGejJ6c.js";export{o as default};
