import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-u1V20KL9.js";import"./position_manage-DakLsil2.js";import"./index-BzdVYWOU.js";export{o as default};
