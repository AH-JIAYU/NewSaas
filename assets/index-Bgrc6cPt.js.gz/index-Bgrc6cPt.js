import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BiWGhVym.js";import"./user_supplier-BpAlBhbQ.js";import"./index-mUezZMLI.js";export{o as default};
