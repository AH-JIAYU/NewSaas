import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CPNWU2L1.js";import"./survey_vip-B_JNe8ye.js";import"./index-DYnJw9TK.js";export{o as default};
