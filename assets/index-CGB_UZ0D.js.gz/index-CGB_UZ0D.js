import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-79ZDgG61.js";import"./dictionary-CZ5rje-g.js";import"./index-Caan35Ad.js";export{o as default};
