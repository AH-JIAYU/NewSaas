import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BUKKMSxt.js";import"./index-CQqA4_Rh.js";import"./use-resolve-button-type-BVhio-Rs.js";export{o as default};
