import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D3yzWV04.js";import"./dictionary-Dqg3YbSE.js";import"./index-C5nmrkzE.js";export{o as default};
