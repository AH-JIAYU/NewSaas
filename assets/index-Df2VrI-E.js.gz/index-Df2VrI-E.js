import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZhjSyJO.js";import"./user_supplier-9uPiH3uP.js";import"./index-CDcFrPzE.js";export{o as default};
