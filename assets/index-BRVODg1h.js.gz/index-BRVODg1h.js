import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bq1PH6tv.js";import"./project_settlement-Biq_RKsA.js";import"./index-IH8YLq6l.js";export{o as default};
