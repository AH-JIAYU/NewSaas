import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-zSCRIMuF.js";import"./index-DQy_kPaF.js";export{m as default};
