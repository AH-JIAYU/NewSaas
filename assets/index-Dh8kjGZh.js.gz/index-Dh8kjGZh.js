import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DGwz11DI.js";import"./dictionary-D2u3kfde.js";import"./index-BEU4aNZB.js";export{o as default};
