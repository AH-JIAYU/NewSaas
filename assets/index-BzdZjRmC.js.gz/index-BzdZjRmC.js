import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Bq4AYF5x.js";import"./index-BG_Y5tap.js";export{m as default};
