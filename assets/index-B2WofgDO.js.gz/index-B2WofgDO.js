import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dd8CODsY.js";import"./user_customer-Dmm4bjFw.js";import"./index-BzdVYWOU.js";import"./apiLoading-IYs59NME.js";export{o as default};
