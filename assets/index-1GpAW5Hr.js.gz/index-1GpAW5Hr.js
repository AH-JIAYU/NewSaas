import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-exDAjTe9.js";import"./dictionary-B79LJSr5.js";import"./index-DHipLI6p.js";export{o as default};
