import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DvNRSCnx.js";import"./index-CzARc10T.js";export{m as default};
