import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dlmmj7jD.js";import"./survey_vip-D7P_ZobV.js";import"./index-CkoP-l3x.js";export{o as default};
