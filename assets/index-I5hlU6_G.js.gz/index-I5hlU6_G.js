import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DtkQ1hbC.js";import"./apiLoading-CNftaca0.js";import"./index-SEhFNywK.js";import"./user_customer-CjuV2G4E.js";export{o as default};
