import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DxnKfsD6.js";import"./dictionary-CINjjpgE.js";import"./index-Bfr0BA5v.js";export{o as default};
