import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BXw0MKfK.js";import"./dictionary-PY3BVFHy.js";import"./index-CWfNE84P.js";export{o as default};
