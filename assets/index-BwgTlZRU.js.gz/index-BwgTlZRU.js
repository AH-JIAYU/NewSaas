import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Dg48v-88.js";import"./index-DblQ9bv_.js";export{m as default};
