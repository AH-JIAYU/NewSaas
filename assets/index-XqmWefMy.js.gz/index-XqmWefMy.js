import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CJqx59xZ.js";import"./index-DQD169NL.js";/* empty css                      */export{o as default};
