import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BPpYCHah.js";import"./index-Cvjxswu7.js";/* empty css                      */export{o as default};
