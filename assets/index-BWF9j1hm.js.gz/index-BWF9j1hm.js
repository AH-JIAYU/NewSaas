import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dl5Lnkjk.js";import"./dictionary-Dl7UA3ye.js";import"./index-BYPnl6Gi.js";export{o as default};
