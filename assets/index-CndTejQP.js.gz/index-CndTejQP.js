import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BJ7IMllK.js";import"./dictionary-F0LGh3MA.js";import"./index-C8XvnDJA.js";export{o as default};
