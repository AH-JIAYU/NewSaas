import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B31njHF_.js";import"./survey_vip-7f8-BTeF.js";import"./index-BSVPXFpA.js";export{o as default};
