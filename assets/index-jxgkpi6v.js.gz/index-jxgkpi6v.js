import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Do_ru-r0.js";import"./index-D0u_a5jY.js";export{m as default};
