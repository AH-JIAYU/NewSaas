import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CK_EHUn7.js";import"./dictionary-DoJ8bmlT.js";import"./index-CnQ4xoV5.js";export{o as default};
