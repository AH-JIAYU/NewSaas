import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-UHvBSamO.js";import"./dictionary-0ipiH2R1.js";import"./index-RSEgFuCn.js";export{o as default};
