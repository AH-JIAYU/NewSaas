import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COuFKkd8.js";import"./dictionary-DFhfZYyw.js";import"./index-D-6WSM-3.js";export{o as default};
