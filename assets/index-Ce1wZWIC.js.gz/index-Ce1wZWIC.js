import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CqKpIWdC.js";import"./survey_vip-CKoGxpLq.js";import"./index-D7cvy14Q.js";export{o as default};
