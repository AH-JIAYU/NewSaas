import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D4T1iHLP.js";import"./position_manage-BmgZg2Us.js";import"./index-ENwBEqA1.js";export{o as default};
