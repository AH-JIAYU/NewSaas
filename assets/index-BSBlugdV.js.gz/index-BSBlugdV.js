import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BxJAzRjL.js";import"./projectManagement-tP6gGYgd.js";import"./index-B3X1V31b.js";export{o as default};
