import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BqQiWgcM.js";import"./dictionary-DKrOik0E.js";import"./index-BVVfrBYG.js";export{o as default};
