import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-xcF9YnyT.js";import"./dictionary-C-LDhwTz.js";import"./index-CWgqmEzW.js";export{o as default};
