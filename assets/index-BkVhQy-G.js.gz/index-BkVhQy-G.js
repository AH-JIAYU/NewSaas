import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-FIyd8GRY.js";import"./dictionary-C3DEARhj.js";import"./index-fYlMJeDp.js";export{o as default};
