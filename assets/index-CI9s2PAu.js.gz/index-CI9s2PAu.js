import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CXggU1wB.js";import"./project_settlement-Dz69JEPc.js";import"./index-BWZuMFuC.js";export{o as default};
