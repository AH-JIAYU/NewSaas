import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dn3sBzbP.js";import"./dictionary-B8O3mi2N.js";import"./index-BSaSDwJk.js";export{o as default};
