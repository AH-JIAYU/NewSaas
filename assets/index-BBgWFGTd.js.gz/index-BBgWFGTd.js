import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CSxcTrXa.js";import"./user_customer-yWU8hAcQ.js";import"./index-D7cvy14Q.js";import"./apiLoading-Dhz3zFQu.js";export{o as default};
