import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ci0v0_7p.js";import"./user_customer-DJQeDoU-.js";import"./index-D1NMD0Fi.js";import"./apiLoading-zoa22cyC.js";export{o as default};
