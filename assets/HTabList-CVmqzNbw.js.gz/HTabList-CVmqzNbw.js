import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Bb2qKz3K.js";import"./index-AMUerYFu.js";import"./use-resolve-button-type-CBsvsFjQ.js";export{o as default};
