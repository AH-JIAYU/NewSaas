import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dc4ho12C.js";import"./dictionary-CQt57IRT.js";import"./index-B1sH2CRZ.js";export{o as default};
