import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DbMv4wZs.js";import"./dictionary-DZkLaS1n.js";import"./index-D9IZPIam.js";export{o as default};
