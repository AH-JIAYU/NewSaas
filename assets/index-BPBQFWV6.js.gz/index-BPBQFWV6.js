import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CfMOrTpT.js";import"./index-BldWHR0B.js";/* empty css                      */export{o as default};
