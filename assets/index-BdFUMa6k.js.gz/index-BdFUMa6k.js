import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1UzCfvF.js";import"./dictionary-nBATX4up.js";import"./index-Bj5WHarE.js";export{o as default};
