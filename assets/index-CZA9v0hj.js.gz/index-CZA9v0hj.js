import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CDK0vspY.js";import"./index-CKEPio7S.js";import"./role-BFKTiZcO.js";export{o as default};
