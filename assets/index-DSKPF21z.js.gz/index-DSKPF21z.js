import{_ as o}from"./index.vue_vue_type_script_setup_true_lang--FhdGVlv.js";import"./position_manage-DaApZj5s.js";import"./index-ODJju0Ft.js";export{o as default};
