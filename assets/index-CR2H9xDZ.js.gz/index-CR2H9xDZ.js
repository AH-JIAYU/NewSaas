import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-3ttPfb7-.js";import"./dictionary-B9QxPbAu.js";import"./index-CASSY2JL.js";export{o as default};
