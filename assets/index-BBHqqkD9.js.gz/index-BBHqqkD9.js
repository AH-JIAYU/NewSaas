import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-t-Xaw7FE.js";import"./index-BpCZv0AG.js";/* empty css                      */export{o as default};
