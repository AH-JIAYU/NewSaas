import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BsNN9g3o.js";import"./index-B32N5rJq.js";/* empty css                      */export{o as default};
