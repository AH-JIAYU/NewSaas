import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DIF0GUyL.js";import"./index-DcwR6RNz.js";/* empty css                      */export{o as default};
