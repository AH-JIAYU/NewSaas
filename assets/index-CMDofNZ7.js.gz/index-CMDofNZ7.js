import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-PTAi6ek6.js";import"./dictionary-DeuwKVEq.js";import"./index-BDT0MVn7.js";export{o as default};
