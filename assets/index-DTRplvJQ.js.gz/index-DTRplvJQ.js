import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BR_5YFSW.js";import"./survey_vip-DgY647_z.js";import"./index-BREq8xVh.js";export{o as default};
