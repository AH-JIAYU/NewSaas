import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ly525cN7.js";import"./index-Iao0X4w3.js";/* empty css                      */export{o as default};
