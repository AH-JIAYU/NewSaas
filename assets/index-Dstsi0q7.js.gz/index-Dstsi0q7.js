import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CM0VN0Y6.js";import"./dictionary-Dc4t7URT.js";import"./index-Dh-iMYnr.js";export{o as default};
