import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-tC-63y-1.js";import"./index-ynKxKXgj.js";export{m as default};
