import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BEvQN30j.js";import"./index-DqXF3IM4.js";import"./use-resolve-button-type-BdEcJW7v.js";export{o as default};
