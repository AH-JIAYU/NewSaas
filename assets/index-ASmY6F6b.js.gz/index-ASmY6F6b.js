import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cigo17EN.js";import"./dictionary-CkhQkyA8.js";import"./index-B7HNXvov.js";export{o as default};
