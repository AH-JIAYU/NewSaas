import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BvZz8px1.js";import"./index-BsojuIyX.js";/* empty css                      */export{o as default};
