import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DD4UIvai.js";import"./index-DotqEf4N.js";export{m as default};
