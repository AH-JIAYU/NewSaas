import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BG2Wno-l.js";import"./dictionary-DsrL22kZ.js";import"./index-BSVPXFpA.js";export{o as default};
