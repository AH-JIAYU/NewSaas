import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-TTwEH9uN.js";import"./dictionary-BaZnImUJ.js";import"./index-CaciiYLj.js";export{o as default};
