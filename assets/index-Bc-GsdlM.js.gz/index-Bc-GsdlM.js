import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Qxwfo1Fj.js";import"./user_customer-BkpyRopP.js";import"./index-CWgqmEzW.js";import"./apiLoading-veSSAVkR.js";export{o as default};
