import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Df0e8q0S.js";import"./index-DFP_ze2i.js";/* empty css                      */export{o as default};
