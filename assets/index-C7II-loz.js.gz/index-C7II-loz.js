import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-04UhOJ05.js";import"./dictionary-CfSZ4i7a.js";import"./index-C6CLk4Z_.js";export{o as default};
