import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DqC6Hf2H.js";import"./dictionary-bw98F_5p.js";import"./index-fm4O04o6.js";export{o as default};
