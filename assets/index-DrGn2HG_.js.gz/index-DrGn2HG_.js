import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-W_8VaJGZ.js";import"./dictionary-C73m5IyQ.js";import"./index-DRIhZqkI.js";export{o as default};
