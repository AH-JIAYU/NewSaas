import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COiH3NS3.js";import"./dictionary-DNm0x9wv.js";import"./index-BA9xZLJB.js";export{o as default};
