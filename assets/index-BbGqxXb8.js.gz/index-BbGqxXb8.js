import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-IF-088w0.js";import"./dictionary-XwSN8xfc.js";import"./index-BocU9mIs.js";export{o as default};
