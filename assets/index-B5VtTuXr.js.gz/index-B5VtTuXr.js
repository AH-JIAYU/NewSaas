import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BL0K0HX1.js";import"./dictionary-D6zG4Sr5.js";import"./index-CWtp1ebv.js";export{o as default};
