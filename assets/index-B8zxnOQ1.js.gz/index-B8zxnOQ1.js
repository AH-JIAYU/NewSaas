import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bt9iEt9M.js";import"./dictionary-2DS_Lfyq.js";import"./index-DhOXgAfG.js";export{o as default};
