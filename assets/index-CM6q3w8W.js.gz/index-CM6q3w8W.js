import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DPgc5bMj.js";import"./dictionary-C77G-v5C.js";import"./index-C6aesvjM.js";export{o as default};
