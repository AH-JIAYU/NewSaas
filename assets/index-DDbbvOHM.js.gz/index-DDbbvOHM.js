import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cfa5GL-4.js";import"./apiLoading-C3Jxs3MU.js";import"./index-lVXLlegD.js";import"./user_customer-CE95FZk0.js";export{o as default};
