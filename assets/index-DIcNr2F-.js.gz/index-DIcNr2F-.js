import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BDo0-msx.js";import"./dictionary-D_bMpw7Q.js";import"./index-B9uGOVGJ.js";export{o as default};
