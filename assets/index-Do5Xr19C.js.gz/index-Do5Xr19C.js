import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BNFD49VI.js";import"./survey_vip-DoST2gWF.js";import"./index-DStosuG6.js";export{o as default};
