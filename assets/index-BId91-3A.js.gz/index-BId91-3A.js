import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B83WP8HA.js";import"./index-Cfx4AYRq.js";import"./role-tdHMtgFM.js";export{o as default};
