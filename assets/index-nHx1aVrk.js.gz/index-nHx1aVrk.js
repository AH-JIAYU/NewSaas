import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DfSCBGQi.js";import"./index-CQB6STMM.js";import"./role-DoEL4y8p.js";export{o as default};
