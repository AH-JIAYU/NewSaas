import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C-YtCej-.js";import"./index-6YYRAA_i.js";export{m as default};
