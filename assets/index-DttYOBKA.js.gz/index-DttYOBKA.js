import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-XxY7pfGD.js";import"./project_settlement-C8AOubCz.js";import"./index-BE-pxncy.js";export{o as default};
