import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CR4j1yF-.js";import"./index-s461RT_G.js";import"./use-resolve-button-type-BlvdPvoH.js";export{o as default};
