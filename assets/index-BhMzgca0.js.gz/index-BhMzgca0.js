import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-aQT8u_2K.js";import"./index-BRWHVDWK.js";export{m as default};
