import{k as i}from"./index-CK7oE2zh.js";const e={list:t=>i.get("dict/get/getDict"),itemlist:t=>i.post("dict/get/getDictDataSourceByDictId",t)};export{e as a};
