import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3-r5nif.js";import"./dictionary-DNwWFnnF.js";import"./index-BsetXtVy.js";export{o as default};
