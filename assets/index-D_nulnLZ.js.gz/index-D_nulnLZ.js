import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BaRSPo_t.js";import"./dictionary-CPBHeFvN.js";import"./index-B2fAK_OG.js";export{o as default};
