import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-jf-406Tc.js";import"./index-D_1RSG3C.js";/* empty css                      */export{o as default};
