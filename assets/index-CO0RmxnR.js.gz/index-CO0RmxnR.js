import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-8sG8i-o7.js";import"./index-UDTkPhZq.js";import"./index-CIMaAY30.js";export{o as default};
