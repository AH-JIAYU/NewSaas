import{k as t}from"./index-W9H6fTsO.js";const a={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{a};
