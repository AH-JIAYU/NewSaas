import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BoT-xp9J.js";import"./user_cooperation-DiIcpxSq.js";import"./index-BdNz7r3-.js";export{o as default};
