import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-6PijDEiB.js";import"./apiLoading-D8ud3GC0.js";import"./index-BW4MUnX3.js";import"./user_customer-BGDnVXtv.js";export{o as default};
