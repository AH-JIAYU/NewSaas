import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-kO6t_Gmp.js";import"./position_manage-C54My7e5.js";import"./index-Dp-ZPQFq.js";export{o as default};
