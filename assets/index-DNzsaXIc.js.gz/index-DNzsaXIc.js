import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-q5VE3f-3.js";import"./dictionary-BFbm4lS1.js";import"./index-CMQCj95f.js";export{o as default};
