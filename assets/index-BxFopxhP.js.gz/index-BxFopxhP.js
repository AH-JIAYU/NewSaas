import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-IHghYAV4.js";import"./dictionary-hxkf-Jjg.js";import"./index-CoygfBeY.js";export{o as default};
