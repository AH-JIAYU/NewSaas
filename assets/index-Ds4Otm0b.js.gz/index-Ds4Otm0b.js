import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BEToasI5.js";import"./index-DDbb6e6x.js";export{m as default};
