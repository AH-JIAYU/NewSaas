import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CjsFUXBM.js";import"./dictionary-C-0n6SHv.js";import"./index-BsB66SGI.js";export{o as default};
