import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BS2sXujW.js";import"./index-BtGBeoC7.js";import"./use-resolve-button-type-DjVc1AQH.js";export{o as default};
