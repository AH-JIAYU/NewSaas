import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BhetAUQg.js";import"./dictionary-2golbd2K.js";import"./index-BFW7hAjc.js";export{o as default};
