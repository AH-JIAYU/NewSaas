import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BqH8Gfka.js";import"./index-DSudqXuk.js";/* empty css                      */export{o as default};
