import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-WOFZAxP3.js";import"./dictionary-CyXe0Hkp.js";import"./index-BLcbhJDq.js";export{o as default};
