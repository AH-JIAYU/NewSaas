import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BC89Niyl.js";import"./dictionary-CeuI0bjF.js";import"./index-BseM2dkr.js";export{o as default};
