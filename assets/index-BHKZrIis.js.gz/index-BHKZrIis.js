import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DtCPrjjj.js";import"./index-XH02SKV1.js";/* empty css                      */export{o as default};
