import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-dZ4TU8XB.js";import"./dictionary-CMQwnhsb.js";import"./index-C4R2SyQS.js";export{o as default};
