import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CHpVbBwY.js";import"./index-CedPcfav.js";/* empty css                      */export{o as default};
