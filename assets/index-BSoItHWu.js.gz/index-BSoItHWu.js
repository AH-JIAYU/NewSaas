import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ChIpxT61.js";import"./index-DWw4ZeK5.js";import"./index-AMUerYFu.js";import"./department-BpPmetXR.js";export{o as default};
