import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Dugfi_Bd.js";import"./index-B5L6_y5W.js";export{m as default};
