import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-SkI2E1hZ.js";import"./dictionary-LnmoZbv3.js";import"./index-BItR3vGR.js";export{o as default};
