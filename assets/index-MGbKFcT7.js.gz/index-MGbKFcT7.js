import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D8B-U1R_.js";import"./user_supplier-h59A1Hl5.js";import"./index-DkeSsSat.js";export{o as default};
