import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dec6hBBj.js";import"./index-BuCeI957.js";/* empty css                      */export{o as default};
