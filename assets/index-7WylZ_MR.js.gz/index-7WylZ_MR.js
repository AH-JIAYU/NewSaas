import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BaWF29cK.js";import"./index-UMFAIpvB.js";/* empty css                      */export{o as default};
