import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DUSTbmz5.js";import"./dictionary-BcjnxRjE.js";import"./index-Cq8lTFlm.js";export{o as default};
