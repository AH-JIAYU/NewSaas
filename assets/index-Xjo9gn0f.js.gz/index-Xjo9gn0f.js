import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CXz5GlU6.js";import"./survey_vip-vx3g230S.js";import"./index-CRiLI5We.js";export{o as default};
