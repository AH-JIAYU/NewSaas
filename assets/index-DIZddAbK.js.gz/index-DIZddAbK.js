import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BHOhyUqe.js";import"./dictionary-BoDNydgw.js";import"./index-B0h_n5GD.js";export{o as default};
