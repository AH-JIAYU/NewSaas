import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C-tKbo8C.js";import"./index-BWtuCxpb.js";import"./apiLoading-a-gYtDOv.js";export{o as default};
