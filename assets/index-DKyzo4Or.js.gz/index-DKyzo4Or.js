import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-vPWfJeKJ.js";import"./index-CXk0Cf0_.js";export{m as default};
