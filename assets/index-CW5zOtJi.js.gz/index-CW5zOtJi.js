import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C4FvxBxo.js";import"./position_manage-Bxuh66i-.js";import"./index-DBpMn-zf.js";export{o as default};
