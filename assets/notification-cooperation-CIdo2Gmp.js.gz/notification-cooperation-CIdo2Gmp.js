import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-vesL_EAF.js";import"./index-DQuRfXxB.js";export{m as default};
