import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-VoDyia_X.js";import"./index-BIBEoXX_.js";export{m as default};
