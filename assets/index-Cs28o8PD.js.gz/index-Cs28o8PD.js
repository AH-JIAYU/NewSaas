import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-yxj_5ggE.js";import"./index-DtqcPD5G.js";export{m as default};
