import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-C_g0oReS.js";import"./index-BDq3fI5e.js";import"./use-resolve-button-type-eiZGgN05.js";export{o as default};
