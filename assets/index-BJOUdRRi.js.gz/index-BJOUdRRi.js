import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bui7pDXS.js";import"./dictionary-BKfkx1TD.js";import"./index-BKSxisHz.js";export{o as default};
