import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CbNHw8fK.js";import"./position_manage-vrIUkadN.js";import"./index-Bbr2fCuy.js";export{o as default};
