import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Zzzyf0Jm.js";import"./index-D0we2t1S.js";export{m as default};
