import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CPL0f11c.js";import"./index-JlPL0OoL.js";/* empty css                      */export{o as default};
