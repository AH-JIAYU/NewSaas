import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C8zMWRg4.js";import"./dictionary-BScJvPf5.js";import"./index-Rf4YZOvY.js";export{o as default};
