import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DeGMRqLz.js";import"./dictionary-DfznjDxm.js";import"./index-DBTvNtEV.js";export{o as default};
