import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CEyIjkFg.js";import"./user_customer-EZUmI7gn.js";import"./index-DW6xz9nZ.js";import"./apiLoading-28cuTSYA.js";export{o as default};
