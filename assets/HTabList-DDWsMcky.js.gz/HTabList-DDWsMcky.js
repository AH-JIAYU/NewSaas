import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BhLH2_E4.js";import"./index-BHQWn2jY.js";import"./use-resolve-button-type-BZiocb6b.js";export{o as default};
