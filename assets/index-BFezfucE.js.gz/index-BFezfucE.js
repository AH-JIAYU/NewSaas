import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dn7x2ltB.js";import"./dictionary-DdHeM0Q8.js";import"./index-CxuGvTiO.js";export{o as default};
