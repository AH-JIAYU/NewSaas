import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BZ0Pboxa.js";import"./apiLoading-CrU2cdqk.js";import"./index-BrgIncMk.js";import"./user_customer-KSwQT-TY.js";export{o as default};
