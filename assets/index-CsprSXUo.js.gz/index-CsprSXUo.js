import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-QomqfPcB.js";import"./position_manage-BNh0L0gF.js";import"./index-BsB66SGI.js";export{o as default};
