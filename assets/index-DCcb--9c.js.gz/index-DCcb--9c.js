import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3tr3b5Q.js";import"./dictionary-C4gwzo6K.js";import"./index-OagstPE8.js";export{o as default};
