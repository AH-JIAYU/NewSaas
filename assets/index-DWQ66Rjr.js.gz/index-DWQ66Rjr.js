import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-A529qk-D.js";import"./user_supplier-BoWrR5Ek.js";import"./index-CIit55HQ.js";export{o as default};
