import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-P9qiLq_4.js";import"./dictionary-01jamwO8.js";import"./index-DC7p3Iv9.js";export{o as default};
