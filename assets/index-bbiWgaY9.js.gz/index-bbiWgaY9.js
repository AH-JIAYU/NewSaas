import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BoXQr64Z.js";import"./apiLoading-RoxaqEkJ.js";import"./index-BVVfrBYG.js";import"./user_customer-Bwchq-20.js";export{o as default};
