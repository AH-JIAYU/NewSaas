import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-UF0GNwpk.js";import"./index-B3UlksPs.js";import"./use-resolve-button-type-DH8pn8CR.js";export{o as default};
