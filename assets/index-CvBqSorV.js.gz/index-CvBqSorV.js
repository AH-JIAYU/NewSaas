import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-573eNjTM.js";import"./survey_vip-Cd2Cpb7Y.js";import"./index-UdTJk9b4.js";export{o as default};
