import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-1b5DX1cV.js";import"./index-B5L6_y5W.js";import"./role-BME6QG78.js";export{o as default};
