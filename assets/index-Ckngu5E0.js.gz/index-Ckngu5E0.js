import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DprSdv6h.js";import"./dictionary-oJLuV0XS.js";import"./index-BGuSShNg.js";export{o as default};
