import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bw9-h0GD.js";import"./dictionary-D23mgyTG.js";import"./index-BRyMcolp.js";export{o as default};
