import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bm63-90p.js";import"./index-D9HNE6WS.js";/* empty css                      */export{o as default};
