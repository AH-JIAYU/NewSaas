import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-qo1Nhet8.js";import"./dictionary-BPlsIDD6.js";import"./index-BoPGNH9M.js";export{o as default};
