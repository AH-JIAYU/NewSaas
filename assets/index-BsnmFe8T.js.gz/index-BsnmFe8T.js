import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DdMqfnZ_.js";import"./dictionary-0ZEXH32z.js";import"./index-Ca4QanMD.js";export{o as default};
