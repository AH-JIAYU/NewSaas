import{_ as o}from"./index.vue_vue_type_script_setup_true_lang--ohdh42l.js";import"./user_supplier-Dw4E2rI8.js";import"./index-d9-VSK-e.js";export{o as default};
