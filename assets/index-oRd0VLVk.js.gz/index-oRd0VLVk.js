import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dhj7pwCq.js";import"./dictionary-s30RJ_IB.js";import"./index-PEmQkKwO.js";export{o as default};
