import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1rygFe4.js";import"./dictionary-Bc1UjC-6.js";import"./index-DUXFfjMZ.js";export{o as default};
