import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BZsM9ztn.js";import"./index-BO_elwP_.js";export{m as default};
