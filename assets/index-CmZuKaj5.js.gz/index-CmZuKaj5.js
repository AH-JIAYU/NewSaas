import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ubQi0mVw.js";import"./dictionary-Dod24G-v.js";import"./index-XH02SKV1.js";export{o as default};
