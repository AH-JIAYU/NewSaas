import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BIOROpeq.js";import"./index-C4R2SyQS.js";import"./use-resolve-button-type-B0zEa_oG.js";export{o as default};
