import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C_EyeDF6.js";import"./index-wfZ6lyFc.js";export{m as default};
