import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C4j1w4ch.js";import"./index-C32xF_ni.js";export{m as default};
