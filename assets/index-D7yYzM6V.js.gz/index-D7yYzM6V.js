import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ca9f3bvm.js";import"./user_supplier-_A6wBfzy.js";import"./index-CWe7PirC.js";export{o as default};
