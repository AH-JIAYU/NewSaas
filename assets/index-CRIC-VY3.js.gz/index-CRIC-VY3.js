import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Z8gSrI5h.js";import"./dictionary-D32OPBX5.js";import"./index-C5gylVSa.js";export{o as default};
