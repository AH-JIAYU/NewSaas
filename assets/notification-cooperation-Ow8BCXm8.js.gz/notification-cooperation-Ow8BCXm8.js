import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-sJyvM0s3.js";import"./index-XUp5c_5V.js";export{m as default};
