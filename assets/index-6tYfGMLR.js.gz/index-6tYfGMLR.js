import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CvUcrAwZ.js";import"./dictionary-B7Rf7p3n.js";import"./index-ZEGlhzrx.js";export{o as default};
