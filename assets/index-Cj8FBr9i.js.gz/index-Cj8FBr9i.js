import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B-oZWHDU.js";import"./user_customer-DP3kDTQG.js";import"./index-DpfE-7e2.js";import"./apiLoading-DQtsQngU.js";export{o as default};
