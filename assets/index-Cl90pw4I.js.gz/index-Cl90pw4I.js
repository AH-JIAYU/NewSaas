import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CG3Bl0aQ.js";import"./survey_vip-MBpuLy_j.js";import"./index-aj2M0Wo9.js";export{o as default};
