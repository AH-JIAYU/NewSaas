import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B4j_kNSe.js";import"./dictionary-BqDDoku5.js";import"./index-D5iPiNyV.js";export{o as default};
