import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BMVzrnDN.js";import"./apiLoading-BJxM-iOr.js";import"./index-CyfLm8Mb.js";import"./user_customer-DzKuGWSh.js";export{o as default};
