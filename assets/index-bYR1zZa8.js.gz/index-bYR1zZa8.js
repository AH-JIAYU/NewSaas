import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6XfMKxV.js";import"./dictionary-CGHwr-7e.js";import"./index-dvAgep4p.js";export{o as default};
