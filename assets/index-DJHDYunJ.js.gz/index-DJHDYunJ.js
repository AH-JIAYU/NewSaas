import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dxqc0InX.js";import"./dictionary-tmkrFaLm.js";import"./index-CyRDEfVX.js";export{o as default};
