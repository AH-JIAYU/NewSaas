import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-5M_fUbsB.js";import"./index-DQuRfXxB.js";export{m as default};
