import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-D1wedOSs.js";import"./index-BVH6EIfs.js";export{m as default};
