import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ByoHkIp4.js";import"./projectManagement-CrMpCHV4.js";import"./index-DsJowmSc.js";export{o as default};
