import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C-97tMVK.js";import"./index-CmQVGKv8.js";/* empty css                      */export{o as default};
