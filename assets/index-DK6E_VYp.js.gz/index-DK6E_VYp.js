import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B8x4Cr_t.js";import"./index-BCmcck4o.js";export{m as default};
