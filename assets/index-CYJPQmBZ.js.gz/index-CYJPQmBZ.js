import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Due00vym.js";import"./survey_vip-DpbKHmXj.js";import"./index-CBnd12V0.js";export{o as default};
