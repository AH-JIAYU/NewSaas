import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BCkiN75A.js";import"./survey_vip-DCofXpk9.js";import"./index-Djwxgtlr.js";export{o as default};
