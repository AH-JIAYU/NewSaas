import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DuWa91eq.js";import"./dictionary-BlOEr5-H.js";import"./index-BXUKkkrP.js";export{o as default};
