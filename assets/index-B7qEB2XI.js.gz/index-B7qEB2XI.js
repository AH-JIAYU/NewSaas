import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B2_p5noc.js";import"./dictionary-DyQi1Qe6.js";import"./index-CQrZNnCa.js";export{o as default};
