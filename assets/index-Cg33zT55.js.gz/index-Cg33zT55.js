import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CemjME24.js";import"./apiLoading-CQm6JBYp.js";import"./index-BPxxK-md.js";import"./user_customer-DfMWpVGt.js";export{o as default};
