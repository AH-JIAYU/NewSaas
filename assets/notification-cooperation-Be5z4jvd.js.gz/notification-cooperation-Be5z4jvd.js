import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-O98aCqCa.js";import"./index-Cv0hhvIB.js";export{m as default};
