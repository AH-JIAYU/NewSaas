import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DwfFI-Lt.js";import"./apiLoading-XnHxHQXo.js";import"./index-CHE_Y-qx.js";import"./user_customer-xGp6TFb-.js";export{o as default};
