import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D5eeNUiW.js";import"./dictionary-Co2bNU5Y.js";import"./index-D8Uul_xR.js";export{o as default};
