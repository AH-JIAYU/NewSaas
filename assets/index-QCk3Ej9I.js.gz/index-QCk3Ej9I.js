import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CUP1Q_Sn.js";import"./index-CYPVF7Jn.js";export{m as default};
