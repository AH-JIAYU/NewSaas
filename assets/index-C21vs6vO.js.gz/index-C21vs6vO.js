import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C8Iq0Tye.js";import"./index-m0_ZzCtf.js";export{m as default};
