import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3p3PyHJ.js";import"./survey_vip-CuDUOVRa.js";import"./index-BTOpGKE4.js";export{o as default};
