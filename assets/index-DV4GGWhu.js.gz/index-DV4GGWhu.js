import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6OAsQa8.js";import"./dictionary-C1ibMAHm.js";import"./index-DgKsYSiF.js";export{o as default};
