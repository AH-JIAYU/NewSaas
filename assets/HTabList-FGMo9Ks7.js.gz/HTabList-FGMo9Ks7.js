import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CKK2O2rR.js";import"./index-D5onk9Ca.js";import"./use-resolve-button-type-Dd2c1i0j.js";export{o as default};
