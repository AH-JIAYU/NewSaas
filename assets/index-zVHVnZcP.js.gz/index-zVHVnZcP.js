import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C2CuwgDm.js";import"./survey_vip-CdGzp0z-.js";import"./index-DxHYClQ9.js";export{o as default};
