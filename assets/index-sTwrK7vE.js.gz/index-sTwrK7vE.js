import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BxJlOoGS.js";import"./apiLoading-vkZ3a4Wj.js";import"./index-B9P-dBk8.js";import"./user_customer-DIUlfGa_.js";export{o as default};
