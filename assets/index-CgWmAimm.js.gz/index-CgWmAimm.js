import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-aZ-ui2dH.js";import"./dictionary-DYsB1g_F.js";import"./index-ClbBwlqU.js";export{o as default};
