import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Da_0AIZZ.js";import"./index-BBQ0m3JZ.js";export{m as default};
