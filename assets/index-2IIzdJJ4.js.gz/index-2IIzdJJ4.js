import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D-m3Sgmq.js";import"./user_supplier-BumBFptq.js";import"./index-DGgnHJGE.js";export{o as default};
