import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BBp2F67R.js";import"./projectManagement-DHIaH5s4.js";import"./index-CAqsVIP2.js";export{o as default};
