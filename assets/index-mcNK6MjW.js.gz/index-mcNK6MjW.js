import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DkFLNwzN.js";import"./dictionary-C3lu8WD5.js";import"./index-CMDhw7rD.js";export{o as default};
