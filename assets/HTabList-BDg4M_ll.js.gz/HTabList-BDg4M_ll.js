import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-_nHYgdAS.js";import"./index-Bh_VDJMf.js";import"./use-resolve-button-type-CF-NWc5L.js";export{o as default};
