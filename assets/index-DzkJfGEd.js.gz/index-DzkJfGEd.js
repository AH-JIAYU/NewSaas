import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DHRa6PeK.js";import"./dictionary-Dkxpa214.js";import"./index-DotqEf4N.js";export{o as default};
