import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BY3AXtf0.js";import"./index-YllKKoVL.js";/* empty css                      */export{o as default};
