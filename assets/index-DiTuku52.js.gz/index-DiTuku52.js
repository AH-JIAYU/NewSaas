import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-fmsoEkGP.js";import"./user_cooperation-C6EktIvZ.js";import"./index-Bax9gD6S.js";export{o as default};
