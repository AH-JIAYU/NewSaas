import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CWvnWDx4.js";import"./projectManagement-DWx48cuh.js";import"./index-Dmg9F5Q1.js";export{o as default};
