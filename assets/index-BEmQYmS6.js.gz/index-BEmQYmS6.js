import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cs0GMWBT.js";import"./project_settlement-BxgumDR6.js";import"./index-CbFbZQLF.js";export{o as default};
