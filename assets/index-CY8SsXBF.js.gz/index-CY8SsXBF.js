import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-84nEYeh3.js";import"./dictionary-CWnpRdg9.js";import"./index-IzvFu4ZI.js";export{o as default};
