import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C8FmtAr8.js";import"./dictionary-BPnbEFjG.js";import"./index-Bil3zl1I.js";export{o as default};
