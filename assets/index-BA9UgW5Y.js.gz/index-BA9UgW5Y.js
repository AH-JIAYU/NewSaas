import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DMCXoKI5.js";import"./user_customer-CpPxnUNN.js";import"./index-C3b6PpKr.js";import"./apiLoading-3H53BeY8.js";export{o as default};
