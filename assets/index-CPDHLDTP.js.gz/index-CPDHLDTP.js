import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B8fnM4vD.js";import"./dictionary-CfiSwZTf.js";import"./index-DVUUodB1.js";export{o as default};
