import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-09ER6nCe.js";import"./dictionary-DjhU-4ze.js";import"./index-Dx7ZN6ED.js";export{o as default};
