import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DVUYmpny.js";import"./project_settlement-So49NhAQ.js";import"./index-BYPnl6Gi.js";export{o as default};
