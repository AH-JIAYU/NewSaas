import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B-C_YDib.js";import"./index-BgZOffyT.js";export{m as default};
