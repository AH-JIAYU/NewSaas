import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DdDMsMd0.js";import"./index-OagstPE8.js";export{m as default};
