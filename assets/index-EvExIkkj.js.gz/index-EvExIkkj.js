import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DvZzZ1z9.js";import"./dictionary-C1XWtKPh.js";import"./index-bSnal74D.js";export{o as default};
