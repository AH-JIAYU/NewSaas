import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bzu4LMBZ.js";import"./index-BHmX7FLT.js";/* empty css                      */export{o as default};
