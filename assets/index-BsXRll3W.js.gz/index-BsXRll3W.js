import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-7vZHqgY0.js";import"./dictionary-BdqSASCt.js";import"./index-DFP_ze2i.js";export{o as default};
