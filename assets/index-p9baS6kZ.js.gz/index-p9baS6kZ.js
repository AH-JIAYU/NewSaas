import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BlDl0lfG.js";import"./dictionary-D9xu3gt1.js";import"./index-DIxl3f8j.js";export{o as default};
