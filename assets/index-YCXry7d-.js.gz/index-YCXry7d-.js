import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DQpIXvSw.js";import"./index-Co6Y74Lw.js";export{m as default};
