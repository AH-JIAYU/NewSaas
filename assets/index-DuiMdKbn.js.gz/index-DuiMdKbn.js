import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CBLVixrK.js";import"./index-i6ANmCxK.js";export{m as default};
