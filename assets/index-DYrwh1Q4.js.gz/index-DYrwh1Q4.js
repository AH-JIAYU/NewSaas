import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Y_HzOaeN.js";import"./dictionary-BRPbdmIX.js";import"./index-BaoGh0WK.js";export{o as default};
