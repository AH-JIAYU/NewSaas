import{_ as m}from"./item.vue_vue_type_script_setup_true_lang-txahUlMU.js";import"./index-BUdUbmhT.js";export{m as default};
