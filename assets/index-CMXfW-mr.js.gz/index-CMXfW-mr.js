import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3jE5gWp.js";import"./dictionary-DAJUoEb7.js";import"./index-Ul7JPfYN.js";export{o as default};
