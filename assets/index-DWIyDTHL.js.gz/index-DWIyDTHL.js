import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CF4H8Amv.js";import"./dictionary-8Ll-e-Cx.js";import"./index-Cz3eoyTV.js";export{o as default};
