import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDK6k4mc.js";import"./user_customer-JLeA3LoV.js";import"./index-Dd_XLnr_.js";import"./apiLoading-ayvD9sB-.js";export{o as default};
