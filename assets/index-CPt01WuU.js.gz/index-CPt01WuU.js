import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CR6C4VMc.js";import"./dictionary-DVl8Qb1s.js";import"./index-DbPEKLOm.js";export{o as default};
