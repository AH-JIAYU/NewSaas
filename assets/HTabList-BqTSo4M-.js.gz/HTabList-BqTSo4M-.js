import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-C0n2lhWh.js";import"./index-BUk67_5S.js";import"./use-resolve-button-type-DdxSGkuj.js";export{o as default};
