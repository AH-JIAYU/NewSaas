import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-5hzEEK5h.js";import"./user_customer-BWqkFrIM.js";import"./index-Co_cyy70.js";import"./apiLoading-L7qezKGR.js";export{o as default};
