import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D2cvHhLo.js";import"./index-DFgFyKCJ.js";/* empty css                      */export{o as default};
