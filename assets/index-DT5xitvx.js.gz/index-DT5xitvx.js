import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-L--K8IVq.js";import"./position_manage-DZOqVxnY.js";import"./index-Dzje_Lk-.js";export{o as default};
