import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-EpzoXkw6.js";import"./index-u6jofjME.js";import"./use-resolve-button-type-B4pS8lae.js";export{o as default};
