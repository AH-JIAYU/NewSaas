import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DltfGI8b.js";import"./projectManagement-CeJX09IR.js";import"./index-B2fAK_OG.js";export{o as default};
