import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DrSCTIYw.js";import"./index-Iao0X4w3.js";export{m as default};
