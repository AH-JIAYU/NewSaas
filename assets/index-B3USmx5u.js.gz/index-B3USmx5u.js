import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CMyMWkyI.js";import"./dictionary-ksa6dLZm.js";import"./index-CCHj64Ko.js";export{o as default};
