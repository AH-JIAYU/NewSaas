import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BYRFVMgF.js";import"./dictionary-F5EiU48u.js";import"./index-6EN4pAdE.js";export{o as default};
