import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B29vPh6b.js";import"./project_settlement-DKldF_8L.js";import"./index-CWtp1ebv.js";export{o as default};
