import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-TzvBTKYm.js";import"./dictionary-FiuQoX6b.js";import"./index-gn7cIfcI.js";export{o as default};
