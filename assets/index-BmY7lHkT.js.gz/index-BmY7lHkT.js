import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B5OqXwEY.js";import"./dictionary-D_X9YQgm.js";import"./index-D_1RSG3C.js";export{o as default};
