import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-1unAlIj-.js";import"./user_supplier-DDH47xsp.js";import"./index-D2mxR2r5.js";export{o as default};
