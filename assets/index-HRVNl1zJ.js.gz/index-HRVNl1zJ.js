import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bk7qzIeu.js";import"./dictionary-DThmBWOh.js";import"./index-BU8GT9R8.js";export{o as default};
