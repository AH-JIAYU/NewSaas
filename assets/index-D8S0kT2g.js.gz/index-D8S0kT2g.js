import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CqwLo4x5.js";import"./dictionary-D2SDpXiX.js";import"./index-BthuLXwd.js";export{o as default};
