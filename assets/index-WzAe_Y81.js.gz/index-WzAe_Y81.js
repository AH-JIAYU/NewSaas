import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-WbisaSlL.js";import"./user_supplier-CqWBy6af.js";import"./index-DFgFyKCJ.js";export{o as default};
