import{k as i}from"./index-C29iptdf.js";const e={list:t=>i.get("dict/get/getDict"),itemlist:t=>i.post("dict/get/getDictDataSourceByDictId",t)};export{e as a};
