import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BYPDuoxy.js";import"./dictionary-BtGJ3D-6.js";import"./index-CKRAJm3S.js";export{o as default};
