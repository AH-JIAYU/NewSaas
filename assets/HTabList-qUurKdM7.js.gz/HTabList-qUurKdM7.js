import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-C6yW1xpJ.js";import"./index-CTDaT2Z5.js";import"./use-resolve-button-type-D-8azz-d.js";export{o as default};
