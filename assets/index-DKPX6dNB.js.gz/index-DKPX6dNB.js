import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Q8MLcb6l.js";import"./dictionary-Dyt4FfgK.js";import"./index-CJyZF_XX.js";export{o as default};
