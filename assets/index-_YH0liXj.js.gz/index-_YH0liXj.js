import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cvb-JKkp.js";import"./projectManagement-SWdcr62z.js";import"./index-BRcV2045.js";export{o as default};
