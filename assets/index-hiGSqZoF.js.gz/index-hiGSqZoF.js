import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-YsoHhi8U.js";import"./index-Csu8ItrT.js";import"./index-OReB-nn0.js";import"./department-DxryLwCd.js";export{o as default};
