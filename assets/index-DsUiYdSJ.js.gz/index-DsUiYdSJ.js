import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6r1_29-.js";import"./dictionary-SBbt2Lz4.js";import"./index-JVwiYWif.js";export{o as default};
