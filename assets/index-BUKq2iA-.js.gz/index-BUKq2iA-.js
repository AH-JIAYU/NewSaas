import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-aDELZuoJ.js";import"./index-DoiK1_dJ.js";export{m as default};
