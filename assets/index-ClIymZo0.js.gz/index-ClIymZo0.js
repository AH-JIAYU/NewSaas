import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C796NTe-.js";import"./survey_vip-De5Z_u6Y.js";import"./index-DWHuUoGG.js";export{o as default};
