import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-BDBhS-jj.js";import"./index-ClKnHj-s.js";export{m as default};
