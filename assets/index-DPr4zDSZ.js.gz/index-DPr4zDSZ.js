import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CYDhq0Ce.js";import"./index-DZ7Gqds7.js";export{m as default};
