import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-KVyAqQE0.js";import"./user_customer-D65jykB5.js";import"./index-CiUEwP-Q.js";import"./apiLoading-B2h5Te4i.js";export{o as default};
