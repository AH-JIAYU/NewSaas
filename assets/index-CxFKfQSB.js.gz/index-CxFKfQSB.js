import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BvqxFVzo.js";import"./survey_vip-B9iN1ja-.js";import"./index-68hOHSHJ.js";export{o as default};
