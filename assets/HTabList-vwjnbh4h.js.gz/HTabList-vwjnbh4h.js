import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DTWX1_6c.js";import"./index-Caw1jFf3.js";import"./use-resolve-button-type-DR9tAQ8a.js";export{o as default};
