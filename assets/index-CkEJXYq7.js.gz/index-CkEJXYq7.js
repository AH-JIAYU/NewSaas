import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Baqitv2J.js";import"./dictionary-Du1Ahqfg.js";import"./index-lVXLlegD.js";export{o as default};
