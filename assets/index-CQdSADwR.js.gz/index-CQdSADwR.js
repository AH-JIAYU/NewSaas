import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BpA7ndIk.js";import"./index-0kgWkY4k.js";export{m as default};
