import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D9cvAi6o.js";import"./dictionary-CB6OwKMg.js";import"./index-BNI25b2r.js";export{o as default};
