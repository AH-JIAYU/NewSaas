import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B3rxejvP.js";import"./index-BaLgkNXx.js";export{m as default};
