import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DF1relyC.js";import"./dictionary-6J60y4-X.js";import"./index-CROH153d.js";export{o as default};
