import{k as i}from"./index-DqTjMncf.js";const e={list:t=>i.get("dict/get/getDict"),itemlist:t=>i.post("dict/get/getDictDataSourceByDictId",t)};export{e as a};
