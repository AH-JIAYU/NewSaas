import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B1Wdv9un.js";import"./user_supplier-CRYbzfck.js";import"./index-3-Luvx0C.js";export{o as default};
