import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DAtjLjZj.js";import"./otherFunctions_screenLibrary-PGsyi3_E.js";import"./index-C5nmrkzE.js";export{o as default};
