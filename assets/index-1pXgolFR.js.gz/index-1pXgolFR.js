import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-sbxQ6GxE.js";import"./index-BtGBeoC7.js";export{m as default};
