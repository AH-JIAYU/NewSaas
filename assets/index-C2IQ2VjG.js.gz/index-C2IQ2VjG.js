import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CxwrY-ja.js";import"./index-DMkc-Xxf.js";export{m as default};
