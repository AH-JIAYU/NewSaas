import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C2aoNm97.js";import"./user_supplier-D4COYjMh.js";import"./index-DwcK68j4.js";export{o as default};
