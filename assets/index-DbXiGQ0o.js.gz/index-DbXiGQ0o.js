import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C2qAf3cT.js";import"./index-DQRW2_Vj.js";/* empty css                      */export{o as default};
