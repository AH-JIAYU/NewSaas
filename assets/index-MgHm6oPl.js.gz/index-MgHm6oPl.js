import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BeUcE6kP.js";import"./dictionary-CSTaGyqK.js";import"./index-B3-mTlCA.js";export{o as default};
