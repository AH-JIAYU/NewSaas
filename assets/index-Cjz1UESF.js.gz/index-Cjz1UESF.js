import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BXzHDkX2.js";import"./survey_vip-BCb20ln7.js";import"./index-B--K0VXZ.js";export{o as default};
