import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DQ2znjqI.js";import"./dictionary-CaHN1yk8.js";import"./index-DZV01Nt9.js";export{o as default};
