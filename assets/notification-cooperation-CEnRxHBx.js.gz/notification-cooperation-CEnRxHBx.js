import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-B2Zc1SqM.js";import"./index-DcqAaBhZ.js";export{m as default};
