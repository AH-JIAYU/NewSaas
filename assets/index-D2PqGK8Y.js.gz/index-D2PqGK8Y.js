import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BW7paGfh.js";import"./survey_vip-Bk4tkidM.js";import"./index-D_Rj23yr.js";export{o as default};
