import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDNhUfzU.js";import"./dictionary-DnuuDl_C.js";import"./index-JhMSEHdj.js";export{o as default};
