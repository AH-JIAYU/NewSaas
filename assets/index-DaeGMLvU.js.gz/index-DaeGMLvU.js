import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-_sTRVHri.js";import"./dictionary-Cn9x34mD.js";import"./index-C5qFWr5w.js";export{o as default};
