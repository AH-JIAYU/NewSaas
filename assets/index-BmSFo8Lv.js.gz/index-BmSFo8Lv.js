import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DUoy1y8y.js";import"./projectManagement-houovOs0.js";import"./index-CxSXUQRU.js";export{o as default};
