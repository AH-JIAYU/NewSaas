import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BKqjs9B0.js";import"./index-BQjh9Koe.js";export{m as default};
