import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-s-ymx8gY.js";import"./position_manage-Bt_lAP9P.js";import"./index-BMiaO8YQ.js";export{o as default};
