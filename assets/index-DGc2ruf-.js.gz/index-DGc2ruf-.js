import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bt7vGEWw.js";import"./user_supplier-CHJ1ZNgP.js";import"./index-CHTO5iG0.js";export{o as default};
