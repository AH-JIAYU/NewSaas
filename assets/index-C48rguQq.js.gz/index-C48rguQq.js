import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CtRzS1Pc.js";import"./dictionary-C-S6hUQ3.js";import"./index-BzANdb3L.js";export{o as default};
