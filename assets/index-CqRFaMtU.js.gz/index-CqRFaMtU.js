import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-A-Qq3GQ-.js";import"./index-DntGxMRg.js";/* empty css                      */export{o as default};
