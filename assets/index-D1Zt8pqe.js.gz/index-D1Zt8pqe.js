import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-w204USev.js";import"./index-UIIVoe2v.js";export{m as default};
