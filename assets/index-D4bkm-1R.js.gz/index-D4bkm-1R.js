import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B4xT_Fwg.js";import"./index-DzccDyec.js";export{m as default};
