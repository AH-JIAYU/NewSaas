import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-zyca0Gn2.js";import"./project_settlement-BmNMG8Da.js";import"./index-DcyX3u0h.js";export{o as default};
