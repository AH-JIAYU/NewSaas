import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B2fXDfVQ.js";import"./index-lJjzSOFx.js";/* empty css                      */export{o as default};
