import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-pUBLGZgk.js";import"./index-BCb3LVAr.js";/* empty css                      */export{o as default};
