import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-cc3j131K.js";import"./index-DB80hXk-.js";/* empty css                      */export{o as default};
