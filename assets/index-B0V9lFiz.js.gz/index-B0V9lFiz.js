import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-uyJAQ5rA.js";import"./dictionary-B7IrF6mG.js";import"./index-CNsz2S3y.js";export{o as default};
