import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BSvYEJNY.js";import"./dictionary-CzYJSc2M.js";import"./index-s461RT_G.js";export{o as default};
