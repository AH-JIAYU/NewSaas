import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Db4JtD0v.js";import"./dictionary-BT7fiuG0.js";import"./index-BqrqSrYO.js";export{o as default};
