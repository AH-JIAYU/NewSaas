import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BXXKB1vQ.js";import"./project_settlement-C-SC8TIK.js";import"./index-P8dMXWZ8.js";export{o as default};
