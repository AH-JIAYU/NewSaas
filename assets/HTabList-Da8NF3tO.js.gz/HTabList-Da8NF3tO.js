import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CHfhyzct.js";import"./index-Bz0tbEGt.js";import"./use-resolve-button-type-B-fWf0Xw.js";export{o as default};
