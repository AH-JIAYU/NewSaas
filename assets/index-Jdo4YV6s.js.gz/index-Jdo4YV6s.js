import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BE6EZGqE.js";import"./apiLoading-y5XIpm4-.js";import"./index-TPKc4hfg.js";import"./user_customer-CsCtAz3S.js";export{o as default};
