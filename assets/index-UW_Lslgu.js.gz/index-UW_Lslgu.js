import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Dbapt4j1.js";import"./index-DDUxF2WW.js";export{m as default};
