import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B-B2IoBJ.js";import"./dictionary-BYncgp64.js";import"./index-CxHAne3j.js";export{o as default};
