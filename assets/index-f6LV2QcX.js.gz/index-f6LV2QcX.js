import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CV6Yp11L.js";import"./survey_vip-BwO4yzW7.js";import"./index-Cercxcm4.js";export{o as default};
