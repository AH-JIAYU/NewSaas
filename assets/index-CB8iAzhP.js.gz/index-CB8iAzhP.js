import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CcpCp4r_.js";import"./index-DJy_89sN.js";/* empty css                      */export{o as default};
