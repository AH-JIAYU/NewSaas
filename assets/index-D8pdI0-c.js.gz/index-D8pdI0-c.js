import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B78SgRYQ.js";import"./dictionary-0z9Gi6Le.js";import"./index-DJ8uzyd-.js";export{o as default};
