import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BA_n6PmM.js";import"./index-v5mc-w_H.js";/* empty css                      */export{o as default};
