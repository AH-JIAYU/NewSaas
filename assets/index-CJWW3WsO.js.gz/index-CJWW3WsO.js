import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bn8dSytF.js";import"./projectManagement-CO1xZIig.js";import"./index-ChQqcNbm.js";export{o as default};
