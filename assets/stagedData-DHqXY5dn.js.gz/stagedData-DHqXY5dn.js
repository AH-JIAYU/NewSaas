import{ah as a,r as e}from"./index-C5nmrkzE.js";const r=a("stagedData",()=>{const t=e(),s=e();return{userCustomer:t,usersupplier:s}}),u=r;export{u};
