import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CIz92cPU.js";import"./index-B5fG_jgi.js";import"./index-Cikis37a.js";import"./department-CP255HcP.js";export{o as default};
