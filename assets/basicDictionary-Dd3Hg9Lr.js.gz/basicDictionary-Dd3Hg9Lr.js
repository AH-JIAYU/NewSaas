import{k as t}from"./index-s9D_0c9m.js";const a={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{a};
