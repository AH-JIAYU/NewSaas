import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-NDarzI2p.js";import"./project_settlement-Ru7yxYlw.js";import"./index-BrgIncMk.js";export{o as default};
