import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DeHKuTEL.js";import"./dictionary-CZLYEaSt.js";import"./index-BFOgWOqQ.js";export{o as default};
