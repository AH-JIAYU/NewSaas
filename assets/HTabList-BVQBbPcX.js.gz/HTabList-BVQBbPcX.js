import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-PlvfqKIk.js";import"./index-BdNuNAfF.js";import"./use-resolve-button-type-CkvfvhyO.js";export{o as default};
