import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B30rlaKm.js";import"./projectManagement-DvAm-Jpq.js";import"./index-C64c0FPw.js";export{o as default};
