import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_WyAZrH.js";import"./dictionary--AT0AkcN.js";import"./index-BzkAC6Ym.js";export{o as default};
