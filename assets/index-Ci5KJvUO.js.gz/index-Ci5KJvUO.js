import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CI7hqPvS.js";import"./dictionary-B5pG6h1A.js";import"./index-DQD169NL.js";export{o as default};
