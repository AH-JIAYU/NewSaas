import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BbU_AiC0.js";import"./user_supplier-KSj-NgBt.js";import"./index-BGeqWhjK.js";export{o as default};
