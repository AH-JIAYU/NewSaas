import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CgQzGsV9.js";import"./index-CCiB9AnP.js";import"./use-resolve-button-type-DcDxuCCS.js";export{o as default};
