import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CQ4HVanT.js";import"./apiLoading-C1KmmSA6.js";import"./index-UMFAIpvB.js";import"./user_customer-tDYWgoqe.js";export{o as default};
