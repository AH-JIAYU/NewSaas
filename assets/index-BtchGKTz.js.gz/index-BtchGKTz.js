import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-eqi2_Gbc.js";import"./dictionary-g_m9f0H4.js";import"./index-CnVmOx-r.js";export{o as default};
