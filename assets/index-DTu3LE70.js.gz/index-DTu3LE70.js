import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BR2izYsf.js";import"./apiLoading-C1j3k8U2.js";import"./index-DXIwLSJH.js";import"./user_customer-m3Fy5Wac.js";export{o as default};
