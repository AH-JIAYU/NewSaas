import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DrYOaB9a.js";import"./dictionary-C6bfYpXB.js";import"./index-Bax9gD6S.js";export{o as default};
