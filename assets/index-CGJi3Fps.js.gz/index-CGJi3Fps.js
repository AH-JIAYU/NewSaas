import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-FgSpKLeP.js";import"./project_settlement-n-s8VAJp.js";import"./index-CxQzir39.js";export{o as default};
