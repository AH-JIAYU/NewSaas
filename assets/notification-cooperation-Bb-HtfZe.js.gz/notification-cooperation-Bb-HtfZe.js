import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-BNrzhDDe.js";import"./index-AMUerYFu.js";export{m as default};
