import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B2G9fWBk.js";import"./user_cooperation-Ccq9gDaB.js";import"./index-Bop26ruM.js";export{o as default};
