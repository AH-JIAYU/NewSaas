import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CuDuJdsr.js";import"./dictionary-CG3si1po.js";import"./index-MokpR8AH.js";export{o as default};
