import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CqUnstKd.js";import"./index-CdX1SWvD.js";import"./use-resolve-button-type-B2qEnv2L.js";export{o as default};
