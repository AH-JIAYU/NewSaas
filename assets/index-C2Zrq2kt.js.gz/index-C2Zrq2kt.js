import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BZVh3xhh.js";import"./index-BQjh9Koe.js";/* empty css                      */export{o as default};
