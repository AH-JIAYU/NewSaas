import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3DJE0NE.js";import"./dictionary-Bw3VaOhp.js";import"./index-D9HNE6WS.js";export{o as default};
