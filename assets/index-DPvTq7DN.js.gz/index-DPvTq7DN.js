import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BWUKHDMf.js";import"./project_settlement-mg673TPM.js";import"./index-Bf0tJ0Rs.js";export{o as default};
