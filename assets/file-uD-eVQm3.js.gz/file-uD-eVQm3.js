import{k as t}from"./index-C5qFWr5w.js";const o={upload:e=>t.post("project/uploadQiniu",e),detail:e=>t.post("project/getQiniuFileUrl",e),delete:e=>t.post("project/deleteQiniu",e)};export{o as f};
