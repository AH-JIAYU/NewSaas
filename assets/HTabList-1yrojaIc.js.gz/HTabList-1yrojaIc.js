import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BgO4IfyE.js";import"./index-Bvg_5MGD.js";import"./use-resolve-button-type--YHFZrK7.js";export{o as default};
