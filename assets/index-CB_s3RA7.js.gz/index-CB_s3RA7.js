import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dfe4Nfy1.js";import"./dictionary-BkO35YJ1.js";import"./index-csWO91SN.js";export{o as default};
