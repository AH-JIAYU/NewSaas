import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-OnHYbQaq.js";import"./index-CRsr9m9e.js";import"./role-uYF6xluz.js";export{o as default};
