import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BbR3BDu3.js";import"./dictionary-BrWivJJI.js";import"./index-Dfh_jK84.js";export{o as default};
