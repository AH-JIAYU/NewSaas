import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DC0-7b7H.js";import"./dictionary-DeMxRa0p.js";import"./index-CgyKQh9o.js";export{o as default};
