import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dn3KS4Y-.js";import"./dictionary-C-SWy9u9.js";import"./index-BwG7OhSu.js";export{o as default};
