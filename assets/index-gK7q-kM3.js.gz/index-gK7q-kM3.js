import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-k-yEO-eV.js";import"./index-DyNgHb7_.js";export{m as default};
