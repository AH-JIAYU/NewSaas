import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DaTA2hK6.js";import"./projectManagement-DZciD6vN.js";import"./index-BLcbhJDq.js";export{o as default};
