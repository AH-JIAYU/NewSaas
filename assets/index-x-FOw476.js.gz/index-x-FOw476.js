import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DCGqPnvM.js";import"./apiLoading-kTZSs_5B.js";import"./index-Dy4b05tF.js";import"./user_customer-CHAaqGr8.js";export{o as default};
