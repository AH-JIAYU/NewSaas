import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BE-4h1TA.js";import"./project_settlement-B7NLIOi3.js";import"./index-Du35Hemh.js";export{o as default};
