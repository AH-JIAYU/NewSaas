import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-9f_4L2fJ.js";import"./index-DyNgHb7_.js";import"./use-resolve-button-type-t6BQnd4w.js";export{o as default};
