import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-C8w4AZ_8.js";import"./index-BCb3LVAr.js";export{m as default};
