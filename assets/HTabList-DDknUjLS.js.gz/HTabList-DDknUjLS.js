import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BXDyKnkJ.js";import"./index-p_p9xnX-.js";import"./use-resolve-button-type-DIzV3Irt.js";export{o as default};
