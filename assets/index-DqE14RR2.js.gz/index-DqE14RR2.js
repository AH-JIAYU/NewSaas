import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DYk_HCya.js";import"./index-CWNW1mmx.js";export{m as default};
