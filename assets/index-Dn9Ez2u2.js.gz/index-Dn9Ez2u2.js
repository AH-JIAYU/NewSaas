import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CmNXp31C.js";import"./dictionary--JU15wOe.js";import"./index-Iao0X4w3.js";export{o as default};
