import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DjOXvIev.js";import"./index-DTbZy0mB.js";/* empty css                      */export{o as default};
