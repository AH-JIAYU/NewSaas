import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DsdGlYPM.js";import"./apiLoading-BtAOL0JJ.js";import"./index-7bVKZbtb.js";import"./user_customer-BMXeuCJq.js";export{o as default};
