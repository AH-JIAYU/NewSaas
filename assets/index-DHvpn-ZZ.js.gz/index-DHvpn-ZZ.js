import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Ce1RjIdD.js";import"./index-BViWRxgD.js";export{m as default};
