import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-sYUWb_8B.js";import"./index-B6vdodWb.js";export{m as default};
