import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DVxERgHU.js";import"./dictionary-xJxKWgW5.js";import"./index-CCHQ00mA.js";export{o as default};
