import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BYl4UcGt.js";import"./project_settlement-CCwIs5u8.js";import"./index-BBQ0m3JZ.js";export{o as default};
