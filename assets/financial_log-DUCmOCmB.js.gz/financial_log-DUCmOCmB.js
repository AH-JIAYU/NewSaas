import{x as t}from"./index-BaLgkNXx.js";const n={list:a=>t.post("staff-financial-record/getTenantStaffFinancialRecordList",a)};export{n as a};
