import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B5OJ1hU_.js";import"./dictionary-xQQMz077.js";import"./index-BsVuAlyA.js";export{o as default};
