import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CtzxVKAa.js";import"./index-MrtRl5Gb.js";import"./use-resolve-button-type-CD3OKmbz.js";export{o as default};
