import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-24amYeiF.js";import"./index-DJy_89sN.js";export{m as default};
