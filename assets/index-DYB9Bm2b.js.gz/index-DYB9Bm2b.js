import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cb_H5gjG.js";import"./dictionary-D5UTG9_y.js";import"./index-0OvYWKzQ.js";export{o as default};
