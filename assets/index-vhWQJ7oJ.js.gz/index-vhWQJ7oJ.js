import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D53vsflC.js";import"./dictionary-BDIA6MKw.js";import"./index-Cjt-OdQA.js";export{o as default};
