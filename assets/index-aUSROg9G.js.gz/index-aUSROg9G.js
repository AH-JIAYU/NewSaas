import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BFpSYYoe.js";import"./apiLoading-omxokyBY.js";import"./index-oDag-wCq.js";import"./user_customer-Bs-_NLVz.js";export{o as default};
