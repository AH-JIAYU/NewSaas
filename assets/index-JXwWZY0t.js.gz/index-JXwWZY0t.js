import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-t91I7N8-.js";import"./dictionary-BfoW93wm.js";import"./index-Dzje_Lk-.js";export{o as default};
