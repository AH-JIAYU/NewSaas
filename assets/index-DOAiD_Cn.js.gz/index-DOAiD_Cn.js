import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cj3W8Ims.js";import"./dictionary-ChPY2OC4.js";import"./index-Ci7w1hVZ.js";export{o as default};
