import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DVXmnf_n.js";import"./index-D_MMeZ-4.js";export{m as default};
