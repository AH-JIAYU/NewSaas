import{k as i}from"./index-CX2PmK0L.js";const e={list:t=>i.get("dict/get/getDict"),itemlist:t=>i.post("dict/get/getDictDataSourceByDictId",t)};export{e as a};
