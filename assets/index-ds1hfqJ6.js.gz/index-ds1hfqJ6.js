import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CuY2b7gs.js";import"./dictionary-DeUOpzXZ.js";import"./index-6I3CLwp1.js";export{o as default};
