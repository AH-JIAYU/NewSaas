import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cjq_dEdm.js";import"./user_supplier-DAB4EjrN.js";import"./index-BkcCYwp6.js";export{o as default};
