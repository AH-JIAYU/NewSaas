import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Co2S57w_.js";import"./dictionary-Cf_dcXQb.js";import"./index-CEjgWoZJ.js";export{o as default};
