import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-soV8fX83.js";import"./index-BaLgkNXx.js";export{m as default};
