import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6R5I-gT.js";import"./dictionary-x-3Hjm--.js";import"./index-DJy_89sN.js";export{o as default};
