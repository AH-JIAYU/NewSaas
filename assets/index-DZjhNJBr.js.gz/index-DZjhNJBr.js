import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ck4lrdYp.js";import"./projectManagement-BrKjSy-e.js";import"./index-B69u0njU.js";export{o as default};
