import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DSvJn9FH.js";import"./dictionary-DEX_Dvhy.js";import"./index-DlPOUnhP.js";export{o as default};
