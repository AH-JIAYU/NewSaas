import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BHBqiISa.js";import"./index-BCb3LVAr.js";import"./use-resolve-button-type-BqYZtVtG.js";export{o as default};
