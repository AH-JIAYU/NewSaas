import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BIkkmQWq.js";import"./dictionary-DwEo0kGL.js";import"./index-Bf0tJ0Rs.js";export{o as default};
