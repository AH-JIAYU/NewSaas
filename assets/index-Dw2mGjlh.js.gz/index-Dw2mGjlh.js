import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDEMHFC9.js";import"./dictionary-BF4wkRw0.js";import"./index-DSINR8nP.js";export{o as default};
