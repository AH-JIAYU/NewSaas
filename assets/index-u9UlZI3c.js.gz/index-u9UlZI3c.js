import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CK2OQYB2.js";import"./apiLoading-Dgox3ppp.js";import"./index-BHfIgYzG.js";import"./user_customer-BzAqJDJz.js";export{o as default};
