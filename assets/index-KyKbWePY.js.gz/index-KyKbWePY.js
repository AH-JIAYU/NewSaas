import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cwf1jqD7.js";import"./dictionary-DgTcRWID.js";import"./index-DaALCnOY.js";export{o as default};
