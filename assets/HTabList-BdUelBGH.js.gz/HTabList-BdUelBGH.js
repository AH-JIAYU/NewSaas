import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DxRC2RIL.js";import"./index-BKSxisHz.js";import"./use-resolve-button-type-3_lZRdKk.js";export{o as default};
