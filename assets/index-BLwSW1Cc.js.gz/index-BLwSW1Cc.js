import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CMYVEbsf.js";import"./index-CJyZF_XX.js";/* empty css                      */export{o as default};
