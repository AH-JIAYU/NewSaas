import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B7mb1-KI.js";import"./user_cooperation-C38xUmNd.js";import"./index-DzqVH_Dc.js";export{o as default};
