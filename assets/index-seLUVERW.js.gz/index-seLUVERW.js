import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bl0GRYTD.js";import"./dictionary-Bj2KZ76k.js";import"./index-BLhj-6I9.js";export{o as default};
