import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DK4LZ44W.js";import"./index-IH8YLq6l.js";/* empty css                      */export{o as default};
