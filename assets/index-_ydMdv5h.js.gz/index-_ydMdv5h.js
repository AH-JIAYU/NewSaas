import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZRv4ru0.js";import"./project_settlement-BW5GAMIv.js";import"./index-C1YYukX-.js";export{o as default};
