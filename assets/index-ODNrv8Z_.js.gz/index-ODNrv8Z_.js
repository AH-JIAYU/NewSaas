import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-g4F1yXRM.js";import"./dictionary-DwrazbYC.js";import"./index-BXk5RD8v.js";export{o as default};
