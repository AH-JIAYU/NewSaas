import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BB6tgWp_.js";import"./index-BL8qUovB.js";export{m as default};
