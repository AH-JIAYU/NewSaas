import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BgIrecF4.js";import"./user_supplier-FSjDCgtV.js";import"./index--d-k_wOm.js";export{o as default};
