import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BwvBVpZq.js";import"./position_manage-B0PXAT80.js";import"./index-rMCvG2s3.js";export{o as default};
