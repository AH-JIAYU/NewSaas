import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DdMx-KrJ.js";import"./dictionary-DGH7zYIJ.js";import"./index-SHuwLsia.js";export{o as default};
