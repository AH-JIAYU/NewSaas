import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DSA2AxEt.js";import"./survey_vip-b2itY9Of.js";import"./index-B-VGS54Q.js";export{o as default};
