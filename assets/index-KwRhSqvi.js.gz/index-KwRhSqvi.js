import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bo6i56WG.js";import"./index-Cq8lTFlm.js";/* empty css                      */export{o as default};
