import{_ as m}from"./item.vue_vue_type_script_setup_true_lang-DcMdNMv_.js";import"./index-CWNW1mmx.js";export{m as default};
