import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BM9aPBu-.js";import"./index-Cg_UlhSM.js";export{m as default};
