import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CE4sKYo7.js";import"./dictionary-ByBnzJDX.js";import"./index-D2v_Je4T.js";export{o as default};
