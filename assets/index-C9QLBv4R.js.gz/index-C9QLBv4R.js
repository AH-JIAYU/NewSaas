import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bx2iG5Na.js";import"./survey_vip-BWovBQlr.js";import"./index-DRUR9hKg.js";export{o as default};
