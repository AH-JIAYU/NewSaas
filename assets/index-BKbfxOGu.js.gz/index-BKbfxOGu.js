import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DK4HBzis.js";import"./dictionary-CMHcJzVH.js";import"./index-D7hUXnf_.js";export{o as default};
