import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-TEu3lzN8.js";import"./dictionary-CgakEV53.js";import"./index-FcBJKWZr.js";export{o as default};
