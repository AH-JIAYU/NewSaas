import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ct81ay87.js";import"./dictionary-B4637km1.js";import"./index-UFkaLSTH.js";export{o as default};
