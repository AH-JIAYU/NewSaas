import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-hD25p4U2.js";import"./index-VWAStke3.js";/* empty css                      */export{o as default};
