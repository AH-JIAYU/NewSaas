import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BR0zZ_Xu.js";import"./index-B0FqJlNV.js";import"./index-PEmQkKwO.js";import"./department-D2Gn_8__.js";export{o as default};
