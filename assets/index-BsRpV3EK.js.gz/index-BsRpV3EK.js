import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZV5zf0z.js";import"./dictionary-uloB2vN4.js";import"./index-B5ofkhVZ.js";export{o as default};
