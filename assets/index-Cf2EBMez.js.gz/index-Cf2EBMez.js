import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-uEvto5AR.js";import"./dictionary-DoU76B5k.js";import"./index-9frZZ7XN.js";export{o as default};
