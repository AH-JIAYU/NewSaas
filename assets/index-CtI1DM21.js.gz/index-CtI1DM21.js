import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ELq-ZqGc.js";import"./dictionary-DWwb13AY.js";import"./index-DntGxMRg.js";export{o as default};
