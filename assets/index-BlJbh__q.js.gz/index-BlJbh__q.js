import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-rZ3am7R4.js";import"./index-C3kxmW5_.js";import"./index-D7ktWcYH.js";import"./department-CaIjgMtb.js";export{o as default};
