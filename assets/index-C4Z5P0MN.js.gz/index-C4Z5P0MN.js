import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-xb7g2ZAd.js";import"./dictionary-BLpS27Y_.js";import"./index-DVhsY0JD.js";export{o as default};
