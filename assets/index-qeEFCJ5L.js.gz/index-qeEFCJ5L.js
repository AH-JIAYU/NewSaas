import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DQVPoEVr.js";import"./index-VLp8k4vq.js";/* empty css                      */export{o as default};
