import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Czvzxhi8.js";import"./dictionary-DiavurrE.js";import"./index-taXVhjKb.js";export{o as default};
