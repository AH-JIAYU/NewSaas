import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3Cj7uFd.js";import"./dictionary-Cdkkg9D5.js";import"./index-BWZuMFuC.js";export{o as default};
