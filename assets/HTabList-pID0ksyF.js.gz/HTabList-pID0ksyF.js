import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-D9Y6rHU-.js";import"./index-BmEoYqke.js";import"./use-resolve-button-type-ByBj6Kyr.js";export{o as default};
