import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DFxGY-EE.js";import"./index-p_-hAVzD.js";import"./index-B9G65lgK.js";import"./department-CMTZSxRS.js";export{o as default};
