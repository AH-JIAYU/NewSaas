import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CYkW_7Ki.js";import"./dictionary-enS9zD6u.js";import"./index-Cs9qlqCQ.js";export{o as default};
