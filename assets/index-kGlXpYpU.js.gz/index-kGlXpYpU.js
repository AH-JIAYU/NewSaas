import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C2mgpB6L.js";import"./survey_vip-2R9XVE3I.js";import"./index-ChTWq2_h.js";export{o as default};
