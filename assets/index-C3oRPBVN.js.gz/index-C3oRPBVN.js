import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CAO47lK0.js";import"./user_customer-CtXbZVhN.js";import"./index-DyNgHb7_.js";import"./apiLoading-LIoRk4dG.js";export{o as default};
