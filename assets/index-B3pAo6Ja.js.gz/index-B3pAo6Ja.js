import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-pb0U-ua_.js";import"./index-BrOEW0VG.js";/* empty css                      */export{o as default};
