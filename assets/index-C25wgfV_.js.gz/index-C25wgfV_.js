import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DR3aUJWg.js";import"./dictionary-B7SIceOe.js";import"./index-4-pQw2v5.js";export{o as default};
