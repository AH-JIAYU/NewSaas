import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DX3K7xR3.js";import"./index-Dm70kv03.js";export{m as default};
