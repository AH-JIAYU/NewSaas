import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ctwl7XpY.js";import"./index-DRUR9hKg.js";/* empty css                      */export{o as default};
