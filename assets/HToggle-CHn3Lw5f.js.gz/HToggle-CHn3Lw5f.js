import{_ as o}from"./HToggle.vue_vue_type_script_setup_true_lang-0RfemosU.js";import"./index-CAPrxn7L.js";import"./use-resolve-button-type-BNZetVK6.js";export{o as default};
