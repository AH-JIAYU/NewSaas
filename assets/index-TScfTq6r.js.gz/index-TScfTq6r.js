import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BPm72tmN.js";import"./index-CWlp4E8u.js";import"./index-CxSXUQRU.js";export{o as default};
