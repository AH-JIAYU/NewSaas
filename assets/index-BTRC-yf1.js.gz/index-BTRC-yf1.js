import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BlY1zuOj.js";import"./project_settlement-D459cz1u.js";import"./index-N5M2KMmX.js";export{o as default};
