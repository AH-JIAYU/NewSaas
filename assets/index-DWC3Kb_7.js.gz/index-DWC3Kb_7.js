import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BAuZ2eZJ.js";import"./dictionary-DJk5oVxE.js";import"./index-u3leq2Mb.js";export{o as default};
