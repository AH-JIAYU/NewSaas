import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CH6QwXzA.js";import"./index-C7CZm4SG.js";import"./use-resolve-button-type-D8vr5QEh.js";export{o as default};
