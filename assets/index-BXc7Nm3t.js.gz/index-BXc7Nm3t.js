import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-4upDtK77.js";import"./index-WSopa337.js";export{m as default};
