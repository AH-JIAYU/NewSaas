import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C0MEvZXm.js";import"./survey_vip-B6GAkt9U.js";import"./index-CXk0Cf0_.js";export{o as default};
