import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BFAPcKQF.js";import"./dictionary-DalPRV4m.js";import"./index-CxQ2sQpP.js";export{o as default};
