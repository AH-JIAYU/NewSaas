import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ErVJNfM2.js";import"./index-BgFpqt2S.js";/* empty css                      */export{o as default};
