import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B9l2XFV6.js";import"./apiLoading-D7bhBL9F.js";import"./index-ChVS5QWJ.js";import"./user_customer-CaiF_pcY.js";export{o as default};
