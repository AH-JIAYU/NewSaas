import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C9aN_q4r.js";import"./projectManagement-Bn1hZnaX.js";import"./index-bSnal74D.js";export{o as default};
