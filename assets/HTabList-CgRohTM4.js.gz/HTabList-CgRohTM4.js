import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CEwB8yU1.js";import"./index-68hOHSHJ.js";import"./use-resolve-button-type-CvY8JtIK.js";export{o as default};
