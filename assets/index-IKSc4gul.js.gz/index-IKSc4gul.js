import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B_lBTuh7.js";import"./project_settlement-C2Orsm74.js";import"./index-BIHh3pBK.js";export{o as default};
