import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ChizEjo2.js";import"./index-Bym8jAMP.js";/* empty css                      */export{o as default};
