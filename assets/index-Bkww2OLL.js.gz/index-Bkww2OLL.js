import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BvMTp2VP.js";import"./dictionary-DFOETNNe.js";import"./index-KFsg0x_i.js";export{o as default};
