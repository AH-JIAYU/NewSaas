import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-SBGXRaij.js";import"./index-DAuqqNLj.js";export{m as default};
