import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DIPuHx7E.js";import"./user_customer-Cg_AmJ91.js";import"./index-hVAcaXkI.js";import"./apiLoading-D44LTxRB.js";export{o as default};
