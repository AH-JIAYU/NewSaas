import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-IiNaqCV_.js";import"./dictionary-HQC6pH7e.js";import"./index-Bbr2fCuy.js";export{o as default};
