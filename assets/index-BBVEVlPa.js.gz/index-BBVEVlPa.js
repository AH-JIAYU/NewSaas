import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CEdIxDwj.js";import"./dictionary-DLYJjhYE.js";import"./index-BRxVf_xq.js";export{o as default};
