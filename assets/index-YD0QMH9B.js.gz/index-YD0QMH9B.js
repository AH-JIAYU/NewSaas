import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DcW6IlhR.js";import"./dictionary-BY_e8UZB.js";import"./index-CWM56v4_.js";export{o as default};
