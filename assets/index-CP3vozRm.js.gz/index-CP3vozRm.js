import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-wjrjfFAW.js";import"./user_cooperation-dghBPRES.js";import"./index-D1CWP657.js";export{o as default};
