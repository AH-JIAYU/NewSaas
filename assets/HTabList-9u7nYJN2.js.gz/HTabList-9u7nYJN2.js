import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CwVM1628.js";import"./index-BzdVYWOU.js";import"./use-resolve-button-type-C4KifMYl.js";export{o as default};
