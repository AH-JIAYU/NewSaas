import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Ch1xsykJ.js";import"./index-C9NBz-v9.js";import"./use-resolve-button-type-ZPUY-qGG.js";export{o as default};
