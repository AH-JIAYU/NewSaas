import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CBl7HxuH.js";import"./user_customer-BPIMD_X3.js";import"./index-HT6UQo4h.js";import"./apiLoading-BFNhjYDl.js";export{o as default};
