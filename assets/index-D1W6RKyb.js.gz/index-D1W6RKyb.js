import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-sI2KrhdC.js";import"./dictionary-CKQF5ol3.js";import"./index-pYKQpb_S.js";export{o as default};
