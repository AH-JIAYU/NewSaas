import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-u3VG9Gsk.js";import"./user_cooperation-lXLJoig5.js";import"./index-DWHuUoGG.js";export{o as default};
