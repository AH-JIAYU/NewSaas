import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Pa4u52mW.js";import"./dictionary-D0w94k8g.js";import"./index-Ci6VJ9pE.js";export{o as default};
