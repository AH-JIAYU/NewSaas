import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CTi70obD.js";import"./dictionary-BvIqJyyN.js";import"./index-C0SI6zwT.js";export{o as default};
