import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CGWqqp_N.js";import"./dictionary-BKbVRXfY.js";import"./index-BwOu4toS.js";export{o as default};
