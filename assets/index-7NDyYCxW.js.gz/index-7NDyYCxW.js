import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-alTdXf3y.js";import"./dictionary-BX_glmAR.js";import"./index-UIIVoe2v.js";export{o as default};
