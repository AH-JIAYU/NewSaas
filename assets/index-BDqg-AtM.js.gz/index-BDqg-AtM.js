import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ClsBbiI9.js";import"./dictionary-D5hSYZjX.js";import"./index-CXk0Cf0_.js";export{o as default};
