import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DRkKE-jy.js";import"./dictionary-C5-KxpLO.js";import"./index-C6kbZRUu.js";export{o as default};
