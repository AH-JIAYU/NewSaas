import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DnHgGLoF.js";import"./otherFunctions_screenLibrary-C_WpUWNQ.js";import"./index-QfOrM8xp.js";export{o as default};
