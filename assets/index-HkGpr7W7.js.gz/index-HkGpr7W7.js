import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BsUUso13.js";import"./position_manage-2c1Tx835.js";import"./index-M5ceogDn.js";export{o as default};
