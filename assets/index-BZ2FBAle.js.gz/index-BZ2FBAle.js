import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DPgX8O1F.js";import"./index-C-YnF30x.js";/* empty css                      */export{o as default};
