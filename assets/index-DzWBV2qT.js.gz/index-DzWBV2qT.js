import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BWR9QLEn.js";import"./index-BTdoUL-I.js";import"./index-DXBclCKb.js";import"./department-xEM8i8_K.js";export{o as default};
