import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-uU6Ais5X.js";import"./dictionary-CjXgO-Vv.js";import"./index-DyjnimEA.js";export{o as default};
