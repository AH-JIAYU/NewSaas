import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DXpsCp-6.js";import"./index-C7GoWkMV.js";export{m as default};
