import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Dw7p6fA-.js";import"./index-BB5MA6Om.js";import"./use-resolve-button-type-Bs4Hs2vj.js";export{o as default};
