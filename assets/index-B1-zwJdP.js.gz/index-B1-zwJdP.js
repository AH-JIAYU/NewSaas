import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-WAWXmvsJ.js";import"./dictionary-EYWF0fqb.js";import"./index-BKR3oNc4.js";export{o as default};
