import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DMqRz6V4.js";import"./index-Dwl3mMDh.js";/* empty css                      */export{o as default};
