import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CwTDFmFW.js";import"./dictionary-BZniPe6n.js";import"./index-DBQUT57V.js";export{o as default};
