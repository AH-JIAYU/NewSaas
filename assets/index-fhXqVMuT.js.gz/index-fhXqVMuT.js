import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CeZ0-sTP.js";import"./dictionary-CDxtfmYR.js";import"./index-BzKbJ4XU.js";export{o as default};
