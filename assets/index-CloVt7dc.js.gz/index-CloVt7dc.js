import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-l2vcVBon.js";import"./index-Q_OhXZcn.js";export{m as default};
