import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BtZmQ-l5.js";import"./dictionary-CPnWfidG.js";import"./index-CLNrgYxp.js";export{o as default};
