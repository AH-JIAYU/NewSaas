import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D47Q6vHv.js";import"./dictionary-XMWDACRf.js";import"./index-CBnd12V0.js";export{o as default};
