import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DbDpl2Q8.js";import"./dictionary-Dh4f0IC-.js";import"./index-XUp5c_5V.js";export{o as default};
