import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bm_9t37n.js";import"./dictionary-CRPBDFAK.js";import"./index-DDUxF2WW.js";export{o as default};
