import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CU5_Np3U.js";import"./index-BsetXtVy.js";export{m as default};
