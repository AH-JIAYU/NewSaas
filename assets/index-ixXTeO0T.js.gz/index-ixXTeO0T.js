import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DWTMky7P.js";import"./dictionary-DRmGM0fG.js";import"./index-BKGdYlTY.js";export{o as default};
