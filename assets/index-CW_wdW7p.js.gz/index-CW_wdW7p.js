import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CXMO7tIP.js";import"./dictionary-R5I96LeJ.js";import"./index-DB80hXk-.js";export{o as default};
