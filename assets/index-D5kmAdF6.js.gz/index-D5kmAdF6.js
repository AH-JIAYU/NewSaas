import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-bOjoj4uB.js";import"./index-CRiLI5We.js";/* empty css                      */export{o as default};
