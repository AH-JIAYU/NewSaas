import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CeB5Nhau.js";import"./index-BrSnL6vk.js";import"./use-resolve-button-type-DdV_QzIQ.js";export{o as default};
