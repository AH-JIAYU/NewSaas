import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BXisEktf.js";import"./dictionary-YONRf59K.js";import"./index-wKxuI42m.js";export{o as default};
