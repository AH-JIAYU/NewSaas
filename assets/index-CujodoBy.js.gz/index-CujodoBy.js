import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DIyyS2W_.js";import"./user_customer-Um3Ufjwv.js";import"./index-AWq_1fCc.js";export{o as default};
