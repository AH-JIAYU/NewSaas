import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-N3B5P8h-.js";import"./dictionary-D8utQb7M.js";import"./index-DY9KDIay.js";export{o as default};
