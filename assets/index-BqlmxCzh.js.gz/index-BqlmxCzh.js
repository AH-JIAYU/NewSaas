import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DUMb8pry.js";import"./dictionary-DzQLsKBO.js";import"./index-C5dUyNPn.js";export{o as default};
