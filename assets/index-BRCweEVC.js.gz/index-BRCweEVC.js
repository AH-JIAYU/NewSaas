import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-7JUIUplt.js";import"./index-KptYxjxV.js";/* empty css                      */export{o as default};
