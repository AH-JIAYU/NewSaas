import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-u586y38l.js";import"./survey_vip-CrQRf_FD.js";import"./index-yv3hHHZ6.js";export{o as default};
