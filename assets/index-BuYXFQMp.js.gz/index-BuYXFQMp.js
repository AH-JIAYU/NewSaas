import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BSD6PuTS.js";import"./user_customer-BZvN8QfM.js";import"./index-3-Luvx0C.js";import"./apiLoading-0Da8pqxZ.js";export{o as default};
