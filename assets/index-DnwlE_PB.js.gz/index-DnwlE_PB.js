import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C5ri19bf.js";import"./index-CMQCj95f.js";export{m as default};
