import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BmcSAf20.js";import"./projectManagement-Bd4iYnM0.js";import"./index-D1BEfC-c.js";export{o as default};
