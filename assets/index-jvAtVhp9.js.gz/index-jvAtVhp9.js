import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CX-xpHkY.js";import"./dictionary-cgWvhXDl.js";import"./index-DaerNgvX.js";export{o as default};
