import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-iyBwoQ8a.js";import"./dictionary-CHibcE-i.js";import"./index-Gn8OeSh9.js";export{o as default};
