import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Bbscdfol.js";import"./index-Bm0TARgf.js";export{m as default};
