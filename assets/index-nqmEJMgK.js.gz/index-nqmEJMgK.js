import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BC8UpVVy.js";import"./user_cooperation-BNOK-JmD.js";import"./index-CfmU-pu3.js";export{o as default};
