import{k as t}from"./index-DcR1bT4S.js";const c={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{c as a};
