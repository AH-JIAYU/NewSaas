import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-W6IFt4_d.js";import"./index-FCgaQ8UK.js";/* empty css                      */export{o as default};
