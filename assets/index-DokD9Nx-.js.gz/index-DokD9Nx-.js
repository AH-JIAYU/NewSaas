import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COaA13fl.js";import"./apiLoading-D8lZkRUU.js";import"./index-BNI25b2r.js";import"./user_customer-BD9FitLD.js";export{o as default};
