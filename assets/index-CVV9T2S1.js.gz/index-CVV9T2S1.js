import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-fa5iKnb1.js";import"./projectManagement-5qIFwJ-N.js";import"./index-BVH6EIfs.js";export{o as default};
