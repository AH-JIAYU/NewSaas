import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ci9_Law5.js";import"./index-gkVyJmAv.js";/* empty css                      */export{o as default};
