import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DHoqhUF5.js";import"./dictionary-Hp9GwDJ4.js";import"./index-BOIe6JP6.js";export{o as default};
