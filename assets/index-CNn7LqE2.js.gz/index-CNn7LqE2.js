import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DM-jH5C2.js";import"./survey_vip-DoRc4dC_.js";import"./index-GiIttBIi.js";export{o as default};
