import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BnY7Fnpl.js";import"./apiLoading-B6ztFsDI.js";import"./index-dvAgep4p.js";import"./user_customer-D8x4eCQS.js";export{o as default};
