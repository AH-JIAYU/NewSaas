import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CYk4K55O.js";import"./dictionary-Cv6eKYXH.js";import"./index-CVi0LzYo.js";export{o as default};
