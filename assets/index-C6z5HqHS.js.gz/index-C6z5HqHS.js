import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-l5y-8iB4.js";import"./dictionary-3pPQ5G34.js";import"./index-BCb3LVAr.js";export{o as default};
