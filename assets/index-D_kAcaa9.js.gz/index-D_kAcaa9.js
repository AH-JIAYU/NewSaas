import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DQl6Sgus.js";import"./dictionary-CP1GC4fK.js";import"./index-CzCGM0rZ.js";export{o as default};
