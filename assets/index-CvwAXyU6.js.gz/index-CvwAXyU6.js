import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DGBc9-WN.js";import"./dictionary-BEjG-FAw.js";import"./index-tHSAnviy.js";export{o as default};
