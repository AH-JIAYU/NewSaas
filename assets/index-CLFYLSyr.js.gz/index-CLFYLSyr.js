import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Bsgch87t.js";import"./index-BWtuCxpb.js";export{m as default};
