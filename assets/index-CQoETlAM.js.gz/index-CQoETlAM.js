import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CCHZiX0L.js";import"./user_cooperation-B7u79BVc.js";import"./index-DY9rXM9g.js";export{o as default};
