import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CDHiawQZ.js";import"./index-Bj5WHarE.js";/* empty css                      */export{o as default};
