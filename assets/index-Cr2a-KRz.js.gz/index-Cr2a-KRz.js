import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-ScLug-N8.js";import"./index-gu6-sLbe.js";export{m as default};
