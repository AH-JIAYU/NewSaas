import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B6Gj31Gm.js";import"./dictionary-DEaq6U8q.js";import"./index-DgjFUJII.js";export{o as default};
