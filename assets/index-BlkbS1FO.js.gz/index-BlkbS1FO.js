import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B2MmyFnK.js";import"./dictionary-Zb_1aunZ.js";import"./index-CKEPio7S.js";export{o as default};
