import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BYa7r-S7.js";import"./index-Djwxgtlr.js";export{m as default};
