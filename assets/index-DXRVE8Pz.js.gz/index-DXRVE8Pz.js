import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BBWykvT-.js";import"./dictionary-DOHfQpKU.js";import"./index-CZbucr5m.js";export{o as default};
