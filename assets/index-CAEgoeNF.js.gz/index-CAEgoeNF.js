import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-GLkoSfEM.js";import"./index-CR_Og9_c.js";import"./role-BpstLszC.js";export{o as default};
