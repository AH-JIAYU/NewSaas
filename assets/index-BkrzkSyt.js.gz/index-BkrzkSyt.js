import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BCAphaQo.js";import"./index-1E3Ahbco.js";export{m as default};
