import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DLvJ0WwN.js";import"./project_settlement-Bnw4RrD4.js";import"./index-DBih9DQ6.js";export{o as default};
