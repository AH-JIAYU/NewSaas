import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DWwrf1AJ.js";import"./dictionary-BhxKgumv.js";import"./index-CCggbm1Q.js";export{o as default};
