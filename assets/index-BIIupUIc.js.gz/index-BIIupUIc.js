import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cu6nXT2d.js";import"./dictionary-B9xDzkLT.js";import"./index-CIvOEn04.js";export{o as default};
