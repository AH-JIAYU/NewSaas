import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D84GcYlS.js";import"./user_supplier-BJWauDAp.js";import"./index-CHeFkowZ.js";export{o as default};
