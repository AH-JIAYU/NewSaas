import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CV1PV92e.js";import"./survey_vip-hJy4j0m4.js";import"./index-D3S8ejkd.js";export{o as default};
