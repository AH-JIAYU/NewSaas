import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CUMjuTk5.js";import"./index-rAk_SUAy.js";export{m as default};
