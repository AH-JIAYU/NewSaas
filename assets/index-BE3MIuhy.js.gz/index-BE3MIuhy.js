import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dd5FUb6B.js";import"./project_settlement-BksaSIw9.js";import"./index-DrndPOKy.js";export{o as default};
