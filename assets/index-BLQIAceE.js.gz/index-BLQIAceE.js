import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BrmXooT_.js";import"./index-DVyTUrDY.js";export{m as default};
