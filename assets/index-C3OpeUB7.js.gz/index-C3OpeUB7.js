import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BMxPUkbK.js";import"./dictionary-Btqi6NpF.js";import"./index-CBZ2Pv-y.js";export{o as default};
