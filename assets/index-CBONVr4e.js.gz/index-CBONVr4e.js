import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DAe6b7h3.js";import"./dictionary-DJSL610P.js";import"./index-Cdd4SEY4.js";export{o as default};
