import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C56WR3Vw.js";import"./index-DELVTV6R.js";import"./index-ClKnHj-s.js";import"./department-DoYZd7p5.js";export{o as default};
