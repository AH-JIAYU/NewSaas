import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CXY2JIOS.js";import"./dictionary-KQpballL.js";import"./index-CTLzQeOb.js";export{o as default};
