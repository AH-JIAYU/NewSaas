import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C3ejfCsn.js";import"./index-ChTWq2_h.js";export{m as default};
