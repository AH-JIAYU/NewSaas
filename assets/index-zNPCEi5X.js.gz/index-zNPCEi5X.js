import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DxYNv2YL.js";import"./dictionary-B4-w1AU6.js";import"./index-Cv0hhvIB.js";export{o as default};
