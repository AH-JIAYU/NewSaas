import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BPrkR6Fe.js";import"./index-BSaSDwJk.js";/* empty css                      */export{o as default};
