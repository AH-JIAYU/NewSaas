import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B1posYh3.js";import"./survey-creator-core.i18n-DA1fh3wM.js";import"./index-C32xF_ni.js";export{o as default};
