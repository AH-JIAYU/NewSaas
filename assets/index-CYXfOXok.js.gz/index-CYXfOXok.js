import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C_zp-gx8.js";import"./index-CRsr9m9e.js";export{m as default};
