import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-xMtbFIk3.js";import"./dictionary-D2xkB6g7.js";import"./index-QP0aXqDP.js";export{o as default};
