import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Co8NL8sL.js";import"./index-76DYku8x.js";import"./use-resolve-button-type-BE6Id6y5.js";export{o as default};
