import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DkW3N_Gu.js";import"./projectManagement-J1eWDAuG.js";import"./index-DVhsY0JD.js";export{o as default};
