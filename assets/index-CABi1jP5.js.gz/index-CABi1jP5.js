import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CtN8OAQK.js";import"./index-OReB-nn0.js";/* empty css                      */export{o as default};
