import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-XPSxZj8e.js";import"./dictionary-BpFOlQxM.js";import"./index-C1YYukX-.js";export{o as default};
