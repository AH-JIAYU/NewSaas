import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DuqLtH6j.js";import"./index-Co_cyy70.js";import"./use-resolve-button-type-C4JHf7B9.js";export{o as default};
