import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dxpj0MnF.js";import"./dictionary-CLzH6KlR.js";import"./index-Dz_36XCL.js";export{o as default};
