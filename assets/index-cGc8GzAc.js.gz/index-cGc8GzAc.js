import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZwHK4eD.js";import"./index-AMUerYFu.js";/* empty css                      */export{o as default};
