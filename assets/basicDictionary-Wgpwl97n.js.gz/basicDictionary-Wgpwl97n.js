import{k as t}from"./index-DYnJw9TK.js";const c={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{c as a};
