import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Bn0Bdrwr.js";import"./index-fxZT0Rtn.js";export{m as default};
