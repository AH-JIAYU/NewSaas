import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CBfrqBTj.js";import"./dictionary-3EBxLkPR.js";import"./index-BEZrX72Q.js";export{o as default};
