import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CikWxvRo.js";import"./user_supplier-7JEaPJnM.js";import"./index-D7pHTQdo.js";export{o as default};
