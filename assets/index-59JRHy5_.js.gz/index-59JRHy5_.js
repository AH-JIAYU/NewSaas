import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-TH3wGFpD.js";import"./user_supplier-DKFzX11C.js";import"./index-DqXF3IM4.js";export{o as default};
