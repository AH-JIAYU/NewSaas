import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DecIV-rh.js";import"./dictionary-Citit7RD.js";import"./index-DG25Z5fj.js";export{o as default};
