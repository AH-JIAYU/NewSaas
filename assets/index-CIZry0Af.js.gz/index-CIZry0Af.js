import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CvHvZTKC.js";import"./dictionary-Cu3rGsgp.js";import"./index-BkvBG0Sh.js";export{o as default};
