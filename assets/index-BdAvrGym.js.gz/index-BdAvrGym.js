import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B7jao-Z-.js";import"./dictionary-D2jkvKM3.js";import"./index-89zCDPqH.js";export{o as default};
