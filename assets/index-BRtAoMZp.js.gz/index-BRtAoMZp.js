import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-PR4iS4t8.js";import"./user_supplier-Ch1Bocx4.js";import"./index-X2GS4PsQ.js";export{o as default};
