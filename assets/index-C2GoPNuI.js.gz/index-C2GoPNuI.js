import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BFXXgAbC.js";import"./user_customer-DFrxJs5R.js";import"./index-D7X-4r4C.js";import"./apiLoading-dxhKf-yO.js";export{o as default};
