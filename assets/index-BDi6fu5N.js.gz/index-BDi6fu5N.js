import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DsC6LJfi.js";import"./dictionary-D2DgFhQ7.js";import"./index-DpYtDcrd.js";export{o as default};
