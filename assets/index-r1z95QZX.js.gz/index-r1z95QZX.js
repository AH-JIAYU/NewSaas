import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C3Ff3ngM.js";import"./index-BeWhji_N.js";export{m as default};
