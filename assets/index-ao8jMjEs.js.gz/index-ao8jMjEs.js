import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BM3F_DRn.js";import"./dictionary-CnWYr1Z_.js";import"./index-Bh_VDJMf.js";export{o as default};
