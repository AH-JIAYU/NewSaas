import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-VxWSfa9T.js";import"./dictionary-GrmNrHUP.js";import"./index-BGn-IkNo.js";export{o as default};
