import{k as t}from"./index-CGMecxe4.js";const a={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{a};
