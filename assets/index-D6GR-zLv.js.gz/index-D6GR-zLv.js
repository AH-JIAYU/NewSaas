import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BN2IOpyi.js";import"./position_manage-fRVrwHNp.js";import"./index-BBQ0m3JZ.js";export{o as default};
