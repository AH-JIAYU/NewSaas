import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BAQ67Qfd.js";import"./dictionary-BM75tstu.js";import"./index-DXBclCKb.js";export{o as default};
