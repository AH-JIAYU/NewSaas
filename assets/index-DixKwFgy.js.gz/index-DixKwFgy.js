import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BD0XpfFH.js";import"./user_customer-D1LzQe4-.js";import"./index-DnPHdPWF.js";import"./apiLoading-CCZKHB2k.js";export{o as default};
