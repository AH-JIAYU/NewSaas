import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B9vDiHZD.js";import"./index-BViWRxgD.js";export{m as default};
