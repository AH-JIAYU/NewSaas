import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C26cL7p2.js";import"./dictionary-DGwMol4T.js";import"./index-dg3DzOoH.js";export{o as default};
