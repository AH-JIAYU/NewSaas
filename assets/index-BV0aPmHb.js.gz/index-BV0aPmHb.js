import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dnh6iqID.js";import"./position_manage-D4dnC09t.js";import"./index-DVUUodB1.js";export{o as default};
