import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-4yl_77DM.js";import"./user_supplier-FVWfHpTb.js";import"./index-CV_e-tAb.js";export{o as default};
