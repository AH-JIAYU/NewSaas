import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BiOt1vAx.js";import"./user_customer-B_KUw3Le.js";import"./index-BtGBeoC7.js";import"./apiLoading-BWIt5krR.js";export{o as default};
