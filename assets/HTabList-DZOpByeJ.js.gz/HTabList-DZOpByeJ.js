import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BWN5RAgZ.js";import"./index-BRxVf_xq.js";import"./use-resolve-button-type-C6JwmllZ.js";export{o as default};
