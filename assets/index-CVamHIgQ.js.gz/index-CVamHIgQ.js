import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-mrWyHsMN.js";import"./projectManagement-DdoMLNxU.js";import"./index-Byg-uC3M.js";export{o as default};
