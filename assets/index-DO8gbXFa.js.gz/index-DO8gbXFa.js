import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BTYh-o2T.js";import"./position_manage-C91Smka0.js";import"./index-Bym8jAMP.js";export{o as default};
