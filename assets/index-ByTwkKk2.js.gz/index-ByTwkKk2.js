import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BZBxQA-3.js";import"./user_customer-4BB02vZx.js";import"./index-BeWhji_N.js";import"./apiLoading-BLBwolrT.js";export{o as default};
