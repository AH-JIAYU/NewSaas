import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BCpKcoth.js";import"./index-hdK8Wcrp.js";import"./role-8VmBpF0o.js";export{o as default};
