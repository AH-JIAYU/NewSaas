import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BJez7sSF.js";import"./dictionary-BudAgjBd.js";import"./index-b3LqPvyy.js";export{o as default};
