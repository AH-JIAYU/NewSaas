import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CYNt03OC.js";import"./index-BCmcck4o.js";/* empty css                      */export{o as default};
