import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DjrgF118.js";import"./user_cooperation-DKJMRx31.js";import"./index-CRiLI5We.js";export{o as default};
