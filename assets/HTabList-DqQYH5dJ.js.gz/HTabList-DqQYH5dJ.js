import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DN9CXl1x.js";import"./index-C0SI6zwT.js";import"./use-resolve-button-type-Bq7FKKAJ.js";export{o as default};
