import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DTNoP9V2.js";import"./user_cooperation-tB3y4GRj.js";import"./index-B7BTTWpJ.js";export{o as default};
