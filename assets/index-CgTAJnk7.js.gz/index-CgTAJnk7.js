import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Br7aCxjL.js";import"./dictionary-CXgSpj4G.js";import"./index-BUk67_5S.js";export{o as default};
