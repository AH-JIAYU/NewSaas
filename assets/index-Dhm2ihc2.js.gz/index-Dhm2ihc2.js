import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dx3bMAe7.js";import"./index-CXflPANZ.js";/* empty css                      */export{o as default};
