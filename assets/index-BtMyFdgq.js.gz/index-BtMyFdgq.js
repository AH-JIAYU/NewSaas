import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-K7YAWug8.js";import"./dictionary-C64_87W5.js";import"./index-BkcCYwp6.js";export{o as default};
