import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CuXtYiDQ.js";import"./dictionary-DivCbnEr.js";import"./index-CIMs2gPi.js";export{o as default};
