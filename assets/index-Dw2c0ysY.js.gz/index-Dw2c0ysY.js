import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CrMd-wg8.js";import"./index-LRRG-Da_.js";/* empty css                      */export{o as default};
