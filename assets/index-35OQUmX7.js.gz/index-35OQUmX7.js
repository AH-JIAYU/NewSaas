import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDIQ6ZZB.js";import"./dictionary-POlOTZZL.js";import"./index-DlUJUCOk.js";export{o as default};
