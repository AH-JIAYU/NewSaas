import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CdJvG1ml.js";import"./index-DZI9-0T5.js";/* empty css                      */export{o as default};
