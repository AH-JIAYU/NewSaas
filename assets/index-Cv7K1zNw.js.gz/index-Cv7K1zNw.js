import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B4hsMAWO.js";import"./dictionary-Dqt2gjrM.js";import"./index-Cg_UlhSM.js";export{o as default};
