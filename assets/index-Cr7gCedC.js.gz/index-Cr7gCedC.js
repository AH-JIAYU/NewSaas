import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CixtNhzk.js";import"./user_cooperation-DyqoP-GJ.js";import"./index-Bp7g2Cx7.js";export{o as default};
