import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-BuaY1kbI.js";import"./index-CIFOFIw0.js";export{m as default};
