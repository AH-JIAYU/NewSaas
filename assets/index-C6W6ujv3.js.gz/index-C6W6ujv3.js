import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-dqczXlgz.js";import"./survey_vip-tnezKol0.js";import"./index-BJnWue-r.js";export{o as default};
