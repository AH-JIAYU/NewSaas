import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CW7sbgD6.js";import"./dictionary-USxOz1I2.js";import"./index-BDq3fI5e.js";export{o as default};
