import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DCozlmQj.js";import"./index-BrOEW0VG.js";import"./use-resolve-button-type-ByVuqfzH.js";export{o as default};
