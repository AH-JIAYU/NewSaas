import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CvvsnVmg.js";import"./survey_vip-DJYAyV0x.js";import"./index-BjTEgIZu.js";export{o as default};
