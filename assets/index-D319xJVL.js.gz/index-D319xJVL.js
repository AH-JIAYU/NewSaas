import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BEUh6Jll.js";import"./index-DIUeIGtu.js";export{m as default};
