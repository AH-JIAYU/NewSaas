import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cu5E-ZQV.js";import"./dictionary-Jvndw8iB.js";import"./index-DcR1bT4S.js";export{o as default};
