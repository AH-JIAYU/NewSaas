import{k as t}from"./index-Dd_XLnr_.js";const a={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{a};
