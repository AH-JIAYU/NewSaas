import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BQfWmEkI.js";import"./index--j4xLQ48.js";/* empty css                      */export{o as default};
