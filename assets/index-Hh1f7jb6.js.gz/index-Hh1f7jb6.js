import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CPvupYqZ.js";import"./user_cooperation-y60evPOI.js";import"./index-f26E4OBE.js";export{o as default};
