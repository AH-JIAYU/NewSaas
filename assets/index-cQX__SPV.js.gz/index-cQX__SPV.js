import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DfvBrlty.js";import"./dictionary-BX1xB2dH.js";import"./index-Bvg0cNZx.js";export{o as default};
