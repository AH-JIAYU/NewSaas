import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COgosuFV.js";import"./dictionary-DiTq9L6-.js";import"./index-CAPrxn7L.js";export{o as default};
