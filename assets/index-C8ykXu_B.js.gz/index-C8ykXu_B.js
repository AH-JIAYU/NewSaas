import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B88v2-cT.js";import"./otherFunctions_screenLibrary-CxuUuMWA.js";import"./index-BtNrG_gL.js";export{o as default};
