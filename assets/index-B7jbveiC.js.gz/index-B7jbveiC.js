import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DHSgenVF.js";import"./dictionary-Co-Roop8.js";import"./index-BKzu9Qjt.js";export{o as default};
