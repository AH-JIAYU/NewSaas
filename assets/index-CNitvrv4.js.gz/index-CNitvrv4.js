import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Ddaxd6Nh.js";import"./index-u6jofjME.js";export{m as default};
