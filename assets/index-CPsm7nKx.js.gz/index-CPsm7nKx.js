import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BIqPrH-n.js";import"./dictionary-MAUMeaVS.js";import"./index-C4dvHyEP.js";export{o as default};
