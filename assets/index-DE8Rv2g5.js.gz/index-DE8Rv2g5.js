import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dyqd37T3.js";import"./dictionary-B3Jm_yoq.js";import"./index-DBih9DQ6.js";export{o as default};
