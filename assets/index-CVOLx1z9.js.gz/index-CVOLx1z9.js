import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BVA_jjy_.js";import"./dictionary-BKH6wfZd.js";import"./index-B6wfMZ3d.js";export{o as default};
