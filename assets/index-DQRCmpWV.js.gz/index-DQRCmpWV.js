import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cdn5v7AD.js";import"./dictionary-y3Ytk_De.js";import"./index-ChVS5QWJ.js";export{o as default};
