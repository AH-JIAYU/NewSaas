import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CE4_RcK1.js";import"./position_manage-DyawWgZ2.js";import"./index-COnDHuuS.js";export{o as default};
