import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DtPdxk8d.js";import"./index-DepouR4d.js";export{m as default};
