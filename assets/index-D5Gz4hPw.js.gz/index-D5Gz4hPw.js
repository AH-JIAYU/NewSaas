import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-D_ItCgly.js";import"./index-DzaSqkjU.js";export{m as default};
