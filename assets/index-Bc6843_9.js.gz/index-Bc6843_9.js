import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B_wcjFr6.js";import"./index-dvAgep4p.js";export{m as default};
