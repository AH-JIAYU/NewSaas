import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cwv813bT.js";import"./dictionary-BaJ0PwAt.js";import"./index-CLIJ1bkJ.js";export{o as default};
