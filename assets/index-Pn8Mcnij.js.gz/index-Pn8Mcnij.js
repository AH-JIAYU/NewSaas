import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-UyR8PSEb.js";import"./index-Gn8OeSh9.js";export{m as default};
