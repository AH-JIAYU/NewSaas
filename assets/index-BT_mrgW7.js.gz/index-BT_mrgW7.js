import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DRVkoc8_.js";import"./dictionary-c6ij8U4Z.js";import"./index-C7CZm4SG.js";export{o as default};
