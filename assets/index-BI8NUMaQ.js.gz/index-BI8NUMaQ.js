import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BAfif6F6.js";import"./index-C7CZm4SG.js";/* empty css                      */export{o as default};
