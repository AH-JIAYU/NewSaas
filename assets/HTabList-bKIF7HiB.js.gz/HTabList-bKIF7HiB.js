import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-O3qDSbQ5.js";import"./index-C_u2Pe4I.js";import"./use-resolve-button-type-Cj70zL7q.js";export{o as default};
