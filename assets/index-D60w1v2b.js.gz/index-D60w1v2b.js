import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Cgc1ovBV.js";import"./index-Bgol3tXS.js";export{m as default};
