import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-owK6wMB6.js";import"./dictionary-CYcrOLDQ.js";import"./index-Cj0XdJq_.js";export{o as default};
