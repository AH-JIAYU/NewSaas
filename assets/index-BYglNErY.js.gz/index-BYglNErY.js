import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BjFRmCHd.js";import"./dictionary-DAptlHh1.js";import"./index-xFIogLdu.js";export{o as default};
