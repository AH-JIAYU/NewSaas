import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CvewZ72I.js";import"./dictionary-BsT04BOo.js";import"./index-Dd_XLnr_.js";export{o as default};
