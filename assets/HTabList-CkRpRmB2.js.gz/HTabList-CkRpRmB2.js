import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-NDZ8dw_y.js";import"./index-DY1UvmQ0.js";import"./use-resolve-button-type-BkDtn-yQ.js";export{o as default};
