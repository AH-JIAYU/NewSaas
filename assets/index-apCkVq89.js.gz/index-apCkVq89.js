import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CXlEovo3.js";import"./dictionary-C3lNOxYE.js";import"./index-BBgVRxyN.js";export{o as default};
