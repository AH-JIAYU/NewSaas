import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Ea_XC4D_.js";import"./index-C4dvHyEP.js";export{m as default};
