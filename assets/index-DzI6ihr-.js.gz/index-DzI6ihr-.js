import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DOz4m2nU.js";import"./dictionary-DOBT3CX4.js";import"./index-Cw-g3-rV.js";export{o as default};
