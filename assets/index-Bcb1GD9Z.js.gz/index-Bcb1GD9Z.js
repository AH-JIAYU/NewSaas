import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DfePohLR.js";import"./user_cooperation-CRQ0YYc0.js";import"./index-Cy3Ir7tY.js";export{o as default};
