import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DN12pRNG.js";import"./user_customer-C-PQVLuI.js";import"./index-CVaGN61L.js";import"./apiLoading-fzwUE5-0.js";export{o as default};
