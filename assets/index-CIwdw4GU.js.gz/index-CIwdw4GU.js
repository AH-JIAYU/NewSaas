import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-zDLwgUGd.js";import"./dictionary-D_igUOwP.js";import"./index-DaxZqrrB.js";export{o as default};
