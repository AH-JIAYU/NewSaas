import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DalQa48C.js";import"./index-B2xkcSEn.js";/* empty css                      */export{o as default};
