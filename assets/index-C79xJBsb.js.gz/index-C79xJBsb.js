import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-sygDWhow.js";import"./index-vhbio0rd.js";export{m as default};
