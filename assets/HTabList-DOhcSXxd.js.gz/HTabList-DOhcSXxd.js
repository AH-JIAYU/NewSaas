import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DOm0hXnd.js";import"./index-J0U3ShSi.js";import"./use-resolve-button-type-Bo6kNYzN.js";export{o as default};
