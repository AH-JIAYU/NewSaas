import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dr3QGnod.js";import"./dictionary-CLkubdQp.js";import"./index-Bp3_84TR.js";export{o as default};
