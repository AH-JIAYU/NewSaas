import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BauhDfZ1.js";import"./dictionary-CTcUvkbS.js";import"./index-DA0dbiYf.js";export{o as default};
