import{_ as o}from"./index.vue_vue_type_script_setup_true_lang--ABXDlWW.js";import"./index-B-E5yRN-.js";/* empty css                      */export{o as default};
