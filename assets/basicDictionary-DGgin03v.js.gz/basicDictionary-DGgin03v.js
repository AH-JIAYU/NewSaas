import{k as t}from"./index-BqEk6xQN.js";const a={list:()=>t.get("dict/get/getDict"),itemlist:i=>t.post("dict/get/getDictDataSourceByDictId",i)};export{a};
