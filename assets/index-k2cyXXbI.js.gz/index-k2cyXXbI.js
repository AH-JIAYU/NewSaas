import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-EPt3oSXs.js";import"./dictionary-BfFjCO52.js";import"./index-BitsiCFM.js";export{o as default};
