import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CJvBr3g8.js";import"./dictionary-CbYKZHr_.js";import"./index-TPKc4hfg.js";export{o as default};
