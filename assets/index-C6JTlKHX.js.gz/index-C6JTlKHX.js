import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DBXYeCWH.js";import"./index-DG25Z5fj.js";/* empty css                      */export{o as default};
