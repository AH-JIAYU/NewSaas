import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B-YIWC7h.js";import"./dictionary-CBrkwKTC.js";import"./index-D1BEfC-c.js";export{o as default};
