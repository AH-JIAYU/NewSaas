import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-YAmuvVvc.js";import"./project_settlement-B8Tc0Wd9.js";import"./index-CLQFNkLK.js";export{o as default};
