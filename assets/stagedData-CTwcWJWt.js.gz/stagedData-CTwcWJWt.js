import{ah as a,r as e}from"./index-C_N3Tfx9.js";const r=a("stagedData",()=>{const t=e(),s=e();return{userCustomer:t,usersupplier:s}}),u=r;export{u};
