import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZHll1i5.js";import"./dictionary-BWCIvhVu.js";import"./index-BIBEoXX_.js";export{o as default};
