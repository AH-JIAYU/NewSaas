import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dv0DUTFV.js";import"./dictionary-M6FyJRjA.js";import"./index-v5mc-w_H.js";export{o as default};
