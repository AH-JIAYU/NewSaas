import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BBsr1hhQ.js";import"./dictionary-DOivOmMY.js";import"./index-CihOwGGH.js";export{o as default};
