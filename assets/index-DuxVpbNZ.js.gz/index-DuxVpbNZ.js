import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C2mD182o.js";import"./index-BgZOffyT.js";/* empty css                      */export{o as default};
