import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DBQX36SV.js";import"./dictionary-Bu34b9CJ.js";import"./index-AMUerYFu.js";export{o as default};
