import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DXtJutwk.js";import"./dictionary-6LWK-zH6.js";import"./index-jX57VCnZ.js";export{o as default};
