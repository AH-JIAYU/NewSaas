import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DZxRI47c.js";import"./apiLoading-BIqHDcZZ.js";import"./index-BVTfYKqX.js";import"./user_customer-BMfGL6Kd.js";export{o as default};
