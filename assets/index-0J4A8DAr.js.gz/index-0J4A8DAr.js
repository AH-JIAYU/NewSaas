import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BqA02Wmj.js";import"./index-aj2M0Wo9.js";export{m as default};
