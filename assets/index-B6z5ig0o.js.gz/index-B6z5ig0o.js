import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bv2KpFSb.js";import"./dictionary-6t1YjjT_.js";import"./index-DwcK68j4.js";export{o as default};
