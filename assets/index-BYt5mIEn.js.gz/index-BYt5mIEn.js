import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CuH6bcF9.js";import"./index-Ch_t1wnJ.js";/* empty css                      */export{o as default};
