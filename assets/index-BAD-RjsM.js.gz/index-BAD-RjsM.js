import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CA20G8dL.js";import"./dictionary-CfMtaEFA.js";import"./index-B2xkcSEn.js";export{o as default};
