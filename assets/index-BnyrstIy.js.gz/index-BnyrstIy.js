import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B4wgJpHI.js";import"./project_settlement-DKc70bJ7.js";import"./index-C5dUyNPn.js";export{o as default};
