import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BxIrbO8p.js";import"./dictionary-D_WFac4m.js";import"./index-DKSqY0Fo.js";export{o as default};
