import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dix0KKrE.js";import"./dictionary-Dagk_lO-.js";import"./index-D7pIq9uP.js";export{o as default};
