import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BDvbdfAB.js";import"./dictionary-p989y70j.js";import"./index-BE-pxncy.js";export{o as default};
