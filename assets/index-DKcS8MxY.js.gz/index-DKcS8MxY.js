import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Docx3xou.js";import"./index-BdHtZquS.js";export{m as default};
