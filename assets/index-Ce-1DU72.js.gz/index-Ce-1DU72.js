import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3We_de2.js";import"./survey_vip-B0VYjjE9.js";import"./index-CHeFkowZ.js";export{o as default};
