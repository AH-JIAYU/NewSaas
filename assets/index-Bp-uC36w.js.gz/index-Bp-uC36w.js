import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C2_fymwg.js";import"./dictionary-D3r0IWIF.js";import"./index-9c9FQ37k.js";export{o as default};
