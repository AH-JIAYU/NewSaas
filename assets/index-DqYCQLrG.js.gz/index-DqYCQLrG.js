import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BBh2rw4m.js";import"./projectManagement-D5wEALqT.js";import"./index-D7AuJkCI.js";export{o as default};
