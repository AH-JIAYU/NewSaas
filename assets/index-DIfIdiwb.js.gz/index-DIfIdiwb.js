import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-NVpH65xn.js";import"./dictionary-tK30Nckr.js";import"./index-DakY7-gQ.js";export{o as default};
