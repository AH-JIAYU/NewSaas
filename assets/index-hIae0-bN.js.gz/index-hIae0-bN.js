import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BjgC-jQ_.js";import"./index-BDWalcy-.js";export{m as default};
