import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cr90X_GU.js";import"./index-D5QRSD_b.js";/* empty css                      */export{o as default};
