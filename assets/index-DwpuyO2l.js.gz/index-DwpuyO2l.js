import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DrKwdRsM.js";import"./user_customer--1zHgqxi.js";import"./index-D5ORY2IZ.js";import"./apiLoading-PAIUZ5lP.js";export{o as default};
