import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DwLuCuSi.js";import"./dictionary-AGwpM5S3.js";import"./index-DG8rCAXq.js";export{o as default};
