import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D7RH0THA.js";import"./position_manage-ZHFGIM1v.js";import"./index-Bb0m2dFC.js";export{o as default};
