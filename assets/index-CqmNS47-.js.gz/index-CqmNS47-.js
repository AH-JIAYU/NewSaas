import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D0Xf3fUw.js";import"./index-BFOgWOqQ.js";/* empty css                      */export{o as default};
