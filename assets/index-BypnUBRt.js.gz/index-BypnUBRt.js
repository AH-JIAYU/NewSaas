import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CjrXag-X.js";import"./dictionary-AOaslYru.js";import"./index-BQA78kSN.js";export{o as default};
