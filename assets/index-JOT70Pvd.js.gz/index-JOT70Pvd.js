import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CkTpNK7I.js";import"./department-DrQv5Etz.js";import"./index-BdHtZquS.js";export{o as default};
