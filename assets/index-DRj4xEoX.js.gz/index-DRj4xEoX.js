import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CpvjHGj8.js";import"./index-DA0YABS8.js";export{m as default};
