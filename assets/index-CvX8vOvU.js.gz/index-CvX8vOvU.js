import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bc3CW2az.js";import"./user_supplier-C1vnk34m.js";import"./index--0_6J0jW.js";export{o as default};
