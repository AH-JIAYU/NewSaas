import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Esa1wye4.js";import"./index-CHE_Y-qx.js";export{m as default};
