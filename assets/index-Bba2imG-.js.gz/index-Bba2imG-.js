import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BdchZ4DC.js";import"./dictionary--9y-JN0I.js";import"./index-D8bP9Oz_.js";export{o as default};
