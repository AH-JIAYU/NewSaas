import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-P6aQ4OgL.js";import"./dictionary-dZzTCpE1.js";import"./index-BfeO8snE.js";export{o as default};
