import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Duu6dJnK.js";import"./dictionary-CzNbgGON.js";import"./index-BBiokp72.js";export{o as default};
