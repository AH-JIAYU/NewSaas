import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CiYas5CQ.js";import"./user_supplier-CewsdIU9.js";import"./index-UMFAIpvB.js";export{o as default};
