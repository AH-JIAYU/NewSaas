import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CoAq63O6.js";import"./index-D7ktWcYH.js";/* empty css                      */export{o as default};
