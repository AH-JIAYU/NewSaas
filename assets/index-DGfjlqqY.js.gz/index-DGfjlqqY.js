import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cvntd_O7.js";import"./dictionary-R1wTYpUY.js";import"./index-BMiaO8YQ.js";export{o as default};
