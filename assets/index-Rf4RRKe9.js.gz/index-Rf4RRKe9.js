import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dd6-04do.js";import"./dictionary-Dwr2P_sv.js";import"./index-Bz0tbEGt.js";export{o as default};
