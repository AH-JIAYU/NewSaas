import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-fVlw-vm6.js";import"./dictionary-Clh7CNLX.js";import"./index-BTGw-NBz.js";export{o as default};
