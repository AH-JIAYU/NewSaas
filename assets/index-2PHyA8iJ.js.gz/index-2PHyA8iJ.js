import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-rYD5ijFa.js";import"./index-CpaKVi3K.js";/* empty css                      */export{o as default};
