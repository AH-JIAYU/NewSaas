import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BGvGfcNg.js";import"./dictionary-_4WSal7u.js";import"./index-Bm0TARgf.js";export{o as default};
