import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-NYfj02a1.js";import"./index-DXBclCKb.js";/* empty css                      */export{o as default};
