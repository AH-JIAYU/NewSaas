import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BWY0_2Wb.js";import"./index-BqEk6xQN.js";/* empty css                      */export{o as default};
