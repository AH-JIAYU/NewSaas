import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDfw5IGj.js";import"./survey_vip-C_qLhYY6.js";import"./index-CJyZF_XX.js";export{o as default};
