import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DoGjlad3.js";import"./dictionary-DLd27Le8.js";import"./index-C60j2paH.js";export{o as default};
