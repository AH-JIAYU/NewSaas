import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-_PmcIch_.js";import"./index-BkkjcPJ2.js";export{m as default};
