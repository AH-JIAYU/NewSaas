import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6ujtBuT.js";import"./dictionary-DQSnOCVR.js";import"./index-fk2hhPE5.js";export{o as default};
