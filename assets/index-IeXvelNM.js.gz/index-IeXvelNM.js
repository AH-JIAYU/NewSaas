import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B1L1EbVc.js";import"./dictionary-BlmYT46I.js";import"./index-BiKb57mX.js";export{o as default};
