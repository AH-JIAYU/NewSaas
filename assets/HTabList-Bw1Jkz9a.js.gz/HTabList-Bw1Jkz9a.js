import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DLsoEkAF.js";import"./index-C6Z_9UGF.js";import"./use-resolve-button-type-ClfUB1GR.js";export{o as default};
