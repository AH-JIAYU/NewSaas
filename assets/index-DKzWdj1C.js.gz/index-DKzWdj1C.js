import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-xVP_zUrY.js";import"./index-CgyKQh9o.js";/* empty css                      */export{o as default};
