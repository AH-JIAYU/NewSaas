import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BuZ5VzgX.js";import"./index-WdaD7n5-.js";/* empty css                      */export{o as default};
