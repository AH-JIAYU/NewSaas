import{_ as o}from"./HToggle.vue_vue_type_script_setup_true_lang-CLXSIYv8.js";import"./index-B--K0VXZ.js";import"./use-resolve-button-type-Dd2dnv91.js";export{o as default};
