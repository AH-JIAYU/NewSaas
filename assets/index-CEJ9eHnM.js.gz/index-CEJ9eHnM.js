import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CqCGjvkP.js";import"./user_customer-BTOEpQZp.js";import"./index-BZHzFsqK.js";import"./apiLoading-C1QlDse9.js";export{o as default};
