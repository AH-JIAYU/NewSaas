import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-uD3ZI-wS.js";import"./user_customer-Bv6SPA4d.js";import"./index-fm4O04o6.js";import"./apiLoading-CE5oUBVs.js";export{o as default};
