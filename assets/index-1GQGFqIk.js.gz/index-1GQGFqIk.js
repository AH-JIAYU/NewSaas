import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-tEjl2RQL.js";import"./index-C6aesvjM.js";/* empty css                      */export{o as default};
