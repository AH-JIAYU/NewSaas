import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CWgReEr-.js";import"./index-BMiaO8YQ.js";/* empty css                      */export{o as default};
