import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-fWW4P7xL.js";import"./dictionary-B4tdjZOk.js";import"./index-D17MTJ4o.js";export{o as default};
