import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-7LHfUOgC.js";import"./dictionary-DmpjbH83.js";import"./index-BgZOffyT.js";export{o as default};
