import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3uM93tJ.js";import"./index-BmzI4w-v.js";/* empty css                      */export{o as default};
