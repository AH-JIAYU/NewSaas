import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DTP_ijT6.js";import"./dictionary-pKMAcGtG.js";import"./index-B3UlksPs.js";export{o as default};
