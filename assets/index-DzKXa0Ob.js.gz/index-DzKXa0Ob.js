import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DilJBwpZ.js";import"./dictionary-2BeHMkcD.js";import"./index-C4MrK0he.js";export{o as default};
