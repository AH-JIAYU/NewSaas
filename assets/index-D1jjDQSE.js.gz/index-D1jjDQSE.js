import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DtA-1_eP.js";import"./dictionary-C5fyGzhp.js";import"./index-DnPHdPWF.js";export{o as default};
