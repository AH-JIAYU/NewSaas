import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-B5bXyF3u.js";import"./index-Cc6n2BiZ.js";export{m as default};
