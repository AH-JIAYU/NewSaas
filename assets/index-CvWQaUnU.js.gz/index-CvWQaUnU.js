import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CWeGY-kQ.js";import"./index-DrKhIxfR.js";import"./role-C90dyi0u.js";export{o as default};
