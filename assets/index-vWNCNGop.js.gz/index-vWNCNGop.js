import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BH63tD9Z.js";import"./index-AWq_1fCc.js";import"./role-CCm0On7T.js";export{o as default};
