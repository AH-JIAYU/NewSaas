import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D4rTYoCO.js";import"./position_manage-V_7lyjCm.js";import"./index-DFgFyKCJ.js";export{o as default};
