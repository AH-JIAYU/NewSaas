import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CnrA4DrQ.js";import"./index-D_0r3zo_.js";export{m as default};
