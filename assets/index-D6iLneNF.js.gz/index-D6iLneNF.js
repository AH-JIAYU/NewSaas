import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BhuYZ7oG.js";import"./project_settlement-CRFkKksF.js";import"./index-D_bJQsF8.js";export{o as default};
