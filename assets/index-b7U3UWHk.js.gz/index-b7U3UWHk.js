import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C4aTf91i.js";import"./index-DmgRXF6j.js";/* empty css                      */export{o as default};
