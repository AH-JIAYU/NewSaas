import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-SlnWHLSW.js";import"./index-CX2PmK0L.js";import"./use-resolve-button-type-Cob5ht9N.js";export{o as default};
