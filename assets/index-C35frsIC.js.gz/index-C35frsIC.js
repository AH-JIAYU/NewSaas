import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CN_Btria.js";import"./project_settlement-BGKHYEJg.js";import"./index-DAoDi_gt.js";export{o as default};
