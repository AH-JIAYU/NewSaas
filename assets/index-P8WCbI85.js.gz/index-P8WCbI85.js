import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BLd1qG16.js";import"./dictionary-DhBpriGI.js";import"./index-1eibXPOg.js";export{o as default};
