import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_bz_NyR.js";import"./apiLoading-DeeluNlj.js";import"./index-C74Hc-Sz.js";import"./user_customer-B9JfmPjD.js";export{o as default};
