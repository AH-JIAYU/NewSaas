import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-kj42j6f0.js";import"./index-CoygfBeY.js";export{m as default};
