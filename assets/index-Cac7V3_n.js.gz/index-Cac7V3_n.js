import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DG_bj_t4.js";import"./survey_vip-BR8Qqm1P.js";import"./index-Dh-iMYnr.js";export{o as default};
