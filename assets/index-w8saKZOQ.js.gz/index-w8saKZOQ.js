import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BZXnyzya.js";import"./dictionary-CjPM3LlE.js";import"./index-CbxE907u.js";export{o as default};
