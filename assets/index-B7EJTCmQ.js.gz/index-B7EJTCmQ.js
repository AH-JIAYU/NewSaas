import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-jQ0V4ow4.js";import"./dictionary-BfX7n0zd.js";import"./index-DLSMcH7e.js";export{o as default};
