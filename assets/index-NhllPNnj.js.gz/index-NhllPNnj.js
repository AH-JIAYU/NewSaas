import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BltSomyj.js";import"./project_settlement-X_NjFUwD.js";import"./index-BDT0MVn7.js";export{o as default};
