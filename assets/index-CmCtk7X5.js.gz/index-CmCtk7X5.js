import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CvGlJaYh.js";import"./dictionary-D5u9Mysp.js";import"./index-D-NYWrJk.js";export{o as default};
