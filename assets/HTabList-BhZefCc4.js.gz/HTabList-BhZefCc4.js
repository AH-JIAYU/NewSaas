import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DnD95h68.js";import"./index-BIB0NVmu.js";import"./use-resolve-button-type-DTHMfces.js";export{o as default};
