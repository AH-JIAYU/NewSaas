import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dx1v3YbO.js";import"./dictionary-DVWQmRFV.js";import"./index-Bgol3tXS.js";export{o as default};
