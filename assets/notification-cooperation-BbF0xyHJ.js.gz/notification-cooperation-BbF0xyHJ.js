import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-D2kNnjJn.js";import"./index-gn7cIfcI.js";export{m as default};
