import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BnRQP_6j.js";import"./dictionary-BrqebNLh.js";import"./index-BLvcgQu2.js";export{o as default};
