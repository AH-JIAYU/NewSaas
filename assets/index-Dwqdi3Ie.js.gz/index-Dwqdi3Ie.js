import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D7DPoydz.js";import"./index-6I3CLwp1.js";/* empty css                      */export{o as default};
