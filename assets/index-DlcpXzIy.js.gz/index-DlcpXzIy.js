import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BiviLsRb.js";import"./user_customer-DirDDFi0.js";import"./index-CNsz2S3y.js";import"./apiLoading-qY9zf6_U.js";export{o as default};
