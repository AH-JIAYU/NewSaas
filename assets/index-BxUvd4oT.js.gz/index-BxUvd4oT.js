import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CzN5OneK.js";import"./dictionary-CN96L3LV.js";import"./index-DYnJw9TK.js";export{o as default};
