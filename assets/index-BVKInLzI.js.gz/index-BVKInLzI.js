import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CEbEqopE.js";import"./projectManagement-D8o-pfG6.js";import"./index-BFZzm-5X.js";export{o as default};
