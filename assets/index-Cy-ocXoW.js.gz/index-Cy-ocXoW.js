import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-fpwRn3ao.js";import"./index-P8dMXWZ8.js";/* empty css                      */export{o as default};
