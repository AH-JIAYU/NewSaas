import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DQrDT7eX.js";import"./dictionary-B0QKE4ug.js";import"./index-D_bJQsF8.js";export{o as default};
