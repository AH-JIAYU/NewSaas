import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BmE6DpGA.js";import"./index-DYmXwPhA.js";export{m as default};
