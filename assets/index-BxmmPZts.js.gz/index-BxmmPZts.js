import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DjgCQ_f1.js";import"./project_settlement-xMPb2YPo.js";import"./index-BSaSDwJk.js";export{o as default};
