import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-FWIgK2rS.js";import"./index-Bb0m2dFC.js";import"./use-resolve-button-type-DB29SIK7.js";export{o as default};
