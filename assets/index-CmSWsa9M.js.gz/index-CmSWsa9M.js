import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C0Y2zDjr.js";import"./index-CHlyMxym.js";/* empty css                      */export{o as default};
