import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-qsAvOUKg.js";import"./user_supplier-BM1UN2Cj.js";import"./index-DTh73JDj.js";export{o as default};
