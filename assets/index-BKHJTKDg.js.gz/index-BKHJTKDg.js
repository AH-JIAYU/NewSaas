import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CDcJ1igP.js";import"./dictionary-DTlCGI_N.js";import"./index-B-E5yRN-.js";export{o as default};
