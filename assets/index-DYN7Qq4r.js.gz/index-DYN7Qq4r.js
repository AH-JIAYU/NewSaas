import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BoYlrIRQ.js";import"./dictionary-BeIqXAWz.js";import"./index-BJnWue-r.js";export{o as default};
