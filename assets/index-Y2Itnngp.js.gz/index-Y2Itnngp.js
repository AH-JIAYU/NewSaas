import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COlfhUQZ.js";import"./dictionary-DhYNzMQs.js";import"./index-DrndPOKy.js";export{o as default};
