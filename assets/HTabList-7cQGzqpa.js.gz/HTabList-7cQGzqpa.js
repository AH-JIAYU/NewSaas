import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BH2U6FKX.js";import"./index-BVN4Z1ED.js";import"./use-resolve-button-type-U0JMRYsM.js";export{o as default};
