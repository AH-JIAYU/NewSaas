import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DWcCbBvx.js";import"./index-Bv9eZwwf.js";export{m as default};
