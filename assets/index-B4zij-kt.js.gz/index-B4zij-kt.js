import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ch0P6yFX.js";import"./index-ClxkxBuo.js";/* empty css                      */export{o as default};
