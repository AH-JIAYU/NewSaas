import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B2K3-t7e.js";import"./dictionary-B4Te8M0s.js";import"./index-4wQrOBBW.js";export{o as default};
