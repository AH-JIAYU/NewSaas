import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BOIQaTQ6.js";import"./project_settlement-DADK3iKA.js";import"./index-DwfJnMpB.js";export{o as default};
