import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C-3Up5oS.js";import"./apiLoading-Biw03w2h.js";import"./index-BqEk6xQN.js";import"./user_customer-_SzLu23P.js";export{o as default};
