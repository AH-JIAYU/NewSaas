import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Dxwfxt4c.js";import"./index-C2gY24yx.js";export{m as default};
