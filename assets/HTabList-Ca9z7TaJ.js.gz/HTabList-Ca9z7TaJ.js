import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-eUI16qew.js";import"./index-BIugTcWm.js";import"./use-resolve-button-type-DdTbEuHZ.js";export{o as default};
