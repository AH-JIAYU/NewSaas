import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-qL1CT3Uq.js";import"./dictionary-Bu9kJYos.js";import"./index-DZCXLDVM.js";export{o as default};
