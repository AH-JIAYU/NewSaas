import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-D-j7tTDE.js";import"./index-DpfE-7e2.js";export{m as default};
