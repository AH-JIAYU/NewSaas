import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CtpYpJfb.js";import"./survey_vip-Cn6mPT1O.js";import"./index-Dv_6cl0G.js";export{o as default};
