import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C5bG8h82.js";import"./user_customer-CKvFKLMu.js";import"./index-N5M2KMmX.js";import"./apiLoading-SShdkAVq.js";export{o as default};
