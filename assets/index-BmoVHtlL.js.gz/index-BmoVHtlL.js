import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D3nS0ATb.js";import"./dictionary-CuTYLqqP.js";import"./index-C3lAKP6f.js";export{o as default};
