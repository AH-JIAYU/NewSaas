import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BXJqgSQt.js";import"./project_settlement-sDMZ63jF.js";import"./index-C7bD4Y39.js";export{o as default};
