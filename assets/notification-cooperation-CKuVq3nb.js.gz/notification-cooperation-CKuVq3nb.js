import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-TNi5Gl3z.js";import"./index-D4axY0XK.js";export{m as default};
