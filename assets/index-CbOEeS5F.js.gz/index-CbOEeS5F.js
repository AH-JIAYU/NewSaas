import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-D3_7k7pC.js";import"./index-DAoDi_gt.js";export{m as default};
