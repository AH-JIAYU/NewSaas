import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B78Ml4HX.js";import"./dictionary-B7qGv8O8.js";import"./index-3-Luvx0C.js";export{o as default};
