import{_ as o}from"./index.vue_vue_type_script_setup_true_lang--I21YKdH.js";import"./project_settlement-R87-ox0T.js";import"./index--d-k_wOm.js";export{o as default};
