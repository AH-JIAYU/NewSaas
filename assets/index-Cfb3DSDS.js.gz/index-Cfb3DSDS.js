import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BYKeHXtr.js";import"./project_settlement-UyILwGAn.js";import"./index-CCggbm1Q.js";export{o as default};
