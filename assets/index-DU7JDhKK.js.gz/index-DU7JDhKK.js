import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BKwvhKpW.js";import"./index-BRL3WwX7.js";import"./announcement-ClVxrG3K.js";import"./index-CyRDEfVX.js";export{o as default};
