import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-_ZSIiMAc.js";import"./dictionary-C-xvE75d.js";import"./index-hVAcaXkI.js";export{o as default};
