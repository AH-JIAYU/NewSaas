import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3rhyDZF.js";import"./dictionary-_nSu8I5X.js";import"./index-BV7R4jFg.js";export{o as default};
