import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-KHcvbR2V.js";import"./dictionary-CzO9UCz9.js";import"./index-Du35Hemh.js";export{o as default};
