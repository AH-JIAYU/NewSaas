import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BUCbA4jj.js";import"./otherFunctions_screenLibrary-Cu8nK3Q-.js";import"./index-DokbPgjC.js";export{o as default};
