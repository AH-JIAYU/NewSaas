import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3QcDFwV.js";import"./index-C5dUyNPn.js";/* empty css                      */export{o as default};
