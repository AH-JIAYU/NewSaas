import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-cUAwS2G1.js";import"./dictionary-Cr7PWAAO.js";import"./index-KptYxjxV.js";export{o as default};
