import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CwmcyXjP.js";import"./survey_vip-BO4Dmjs4.js";import"./index-BRcV2045.js";export{o as default};
