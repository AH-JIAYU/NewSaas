import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DqWKYssk.js";import"./dictionary-Cs1O2V8j.js";import"./index-CudKXuRP.js";export{o as default};
