import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-gRvQVV1D.js";import"./user_supplier-JoJoIE0c.js";import"./index-Dhj0iOXN.js";export{o as default};
