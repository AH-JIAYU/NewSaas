import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CnB91oxO.js";import"./dictionary-BJCmFq9i.js";import"./index-s9D_0c9m.js";export{o as default};
