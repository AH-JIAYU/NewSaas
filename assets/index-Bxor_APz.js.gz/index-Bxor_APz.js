import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BmDYtN5a.js";import"./user_supplier-08F0Rty_.js";import"./index-DDbb6e6x.js";export{o as default};
