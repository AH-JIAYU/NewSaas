import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DLmDviiJ.js";import"./dictionary-BjWPmEt3.js";import"./index-CW3FpIaN.js";export{o as default};
