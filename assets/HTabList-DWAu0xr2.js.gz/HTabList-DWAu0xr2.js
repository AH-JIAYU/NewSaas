import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DKzw9Iz8.js";import"./index-BKGdYlTY.js";import"./use-resolve-button-type-Dfgyl-SJ.js";export{o as default};
