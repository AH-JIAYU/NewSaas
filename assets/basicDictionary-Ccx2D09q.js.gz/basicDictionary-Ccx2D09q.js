import{k as i}from"./index-B5L6_y5W.js";const e={list:t=>i.get("dict/get/getDict"),itemlist:t=>i.post("dict/get/getDictDataSourceByDictId",t)};export{e as a};
