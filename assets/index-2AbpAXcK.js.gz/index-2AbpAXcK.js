import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-TSuuWCpC.js";import"./dictionary-DCXTOw_M.js";import"./index-DbqA3EJE.js";export{o as default};
