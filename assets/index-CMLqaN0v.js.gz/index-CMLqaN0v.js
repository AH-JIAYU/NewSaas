import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B6YUPk_f.js";import"./dictionary-OVfPlnie.js";import"./index-B--K0VXZ.js";export{o as default};
