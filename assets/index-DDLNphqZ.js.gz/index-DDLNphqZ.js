import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DqYpGW2I.js";import"./index-C4R2SyQS.js";/* empty css                      */export{o as default};
