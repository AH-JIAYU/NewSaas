import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cp1xJpRn.js";import"./index-3-Luvx0C.js";/* empty css                      */export{o as default};
