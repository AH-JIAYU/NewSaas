import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D0i5BmvL.js";import"./survey_vip-DTu4nurW.js";import"./index-C66yBkEV.js";export{o as default};
