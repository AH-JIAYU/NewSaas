import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CUsmp_lw.js";import"./index-BQGQSghm.js";import"./use-resolve-button-type-fQJ5bdqD.js";export{o as default};
