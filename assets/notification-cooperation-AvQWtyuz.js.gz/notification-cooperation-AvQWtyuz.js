import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-Bmap-1rl.js";import"./index-CedPcfav.js";export{m as default};
