import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-B00Mt-VI.js";import"./index-BYedTeXc.js";import"./use-resolve-button-type-B9lS5HcU.js";export{o as default};
