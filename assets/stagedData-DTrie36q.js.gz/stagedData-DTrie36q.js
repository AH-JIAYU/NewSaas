import{ah as a,r as e}from"./index-JVwiYWif.js";const r=a("stagedData",()=>{const t=e(),s=e();return{userCustomer:t,usersupplier:s}}),u=r;export{u};
