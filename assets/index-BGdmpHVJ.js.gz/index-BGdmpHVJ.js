import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DPgJYHPG.js";import"./dictionary-CZeb9Kfv.js";import"./index-DJHELA-l.js";export{o as default};
