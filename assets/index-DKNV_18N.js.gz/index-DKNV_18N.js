import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-8BSr8Y8G.js";import"./dictionary-Bl2DFvOl.js";import"./index-BViWRxgD.js";export{o as default};
