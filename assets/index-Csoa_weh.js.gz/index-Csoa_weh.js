import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-IG02XWCF.js";import"./position_manage--uh9IZA0.js";import"./index-C-pApz5G.js";export{o as default};
