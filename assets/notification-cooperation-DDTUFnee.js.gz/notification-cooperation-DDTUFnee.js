import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DrF0l3Yc.js";import"./index-DaerNgvX.js";export{m as default};
