import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CTHUE-co.js";import"./dictionary-9vIDG6p-.js";import"./index-yv3hHHZ6.js";export{o as default};
