import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Dc--ig6t.js";import"./index-DRUR9hKg.js";export{m as default};
