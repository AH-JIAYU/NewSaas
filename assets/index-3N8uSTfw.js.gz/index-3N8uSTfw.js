import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3FkbAux.js";import"./apiLoading-CKQOTOWY.js";import"./index-DoQUqSr7.js";import"./user_customer-_vhaBbZU.js";export{o as default};
