import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cui_0zWs.js";import"./dictionary-BAVdotsZ.js";import"./index-amV3JGuM.js";export{o as default};
