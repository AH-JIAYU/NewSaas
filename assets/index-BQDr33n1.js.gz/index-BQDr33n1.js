import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZV2pXnO.js";import"./index-QfOrM8xp.js";import"./role-0d19pX4a.js";export{o as default};
