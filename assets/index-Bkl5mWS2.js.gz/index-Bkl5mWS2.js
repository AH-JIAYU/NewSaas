import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ce6oaaMt.js";import"./dictionary-BTf-CCdU.js";import"./index-BTdQqKYY.js";export{o as default};
