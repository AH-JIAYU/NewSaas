import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-M5GtA0IJ.js";import"./user_customer-Cia-Ppz8.js";import"./index-kosEbCWA.js";import"./apiLoading-DU-Ie8vM.js";export{o as default};
