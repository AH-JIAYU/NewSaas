import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BsW8MEQ0.js";import"./index-CMNRXjnW.js";import"./use-resolve-button-type-nAhD1rkn.js";export{o as default};
