import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BUKxfBIs.js";import"./dictionary-ByOpgdkr.js";import"./index-Dv_6cl0G.js";export{o as default};
