import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DWC-y_Il.js";import"./user_customer-C9AGN1u9.js";import"./index-BDT0MVn7.js";import"./apiLoading-CwFlWF-5.js";export{o as default};
