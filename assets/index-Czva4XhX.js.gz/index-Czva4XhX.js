import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BiBs0bQm.js";import"./index-ChQqcNbm.js";export{m as default};
