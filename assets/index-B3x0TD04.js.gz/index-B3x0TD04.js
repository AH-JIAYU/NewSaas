import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-En2qiFgY.js";import"./dictionary-BGPSDtrJ.js";import"./index-DXZmiFrw.js";export{o as default};
