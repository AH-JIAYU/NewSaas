import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D1jdFReB.js";import"./survey_vip-C3xOz1pB.js";import"./index-DLyt63yI.js";export{o as default};
