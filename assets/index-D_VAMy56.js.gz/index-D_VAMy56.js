import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bg_mFrwb.js";import"./dictionary-Cvi7JUJe.js";import"./index-DgXGVdVI.js";export{o as default};
