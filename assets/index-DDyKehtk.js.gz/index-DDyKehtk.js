import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B1VIizlH.js";import"./dictionary-iCtZqXS5.js";import"./index-76DYku8x.js";export{o as default};
