import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bi65T2W_.js";import"./user_customer-snxEYECr.js";import"./index-LpvUbtoC.js";import"./apiLoading-WRUUrNZu.js";export{o as default};
