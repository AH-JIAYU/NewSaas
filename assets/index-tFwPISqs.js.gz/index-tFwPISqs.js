import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ija2fU01.js";import"./position_manage-BXUE7FC2.js";import"./index-CSGYhle1.js";export{o as default};
