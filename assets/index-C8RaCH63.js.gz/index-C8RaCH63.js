import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-booZqRvV.js";import"./index-BVN4Z1ED.js";/* empty css                      */export{o as default};
