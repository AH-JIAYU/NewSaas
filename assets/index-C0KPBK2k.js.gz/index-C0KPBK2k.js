import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BSyBVcn-.js";import"./index-BE-pxncy.js";export{m as default};
