import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-N3er-j0x.js";import"./index-c-Fvncv2.js";export{m as default};
