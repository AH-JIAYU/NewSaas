import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BECYFO6f.js";import"./dictionary-D6LjwaC1.js";import"./index-CWNW1mmx.js";export{o as default};
