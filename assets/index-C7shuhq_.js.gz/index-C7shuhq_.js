import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Twa0QOrM.js";import"./dictionary-DuioeZ1v.js";import"./index-BrM9WDxg.js";export{o as default};
