import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DZalVF25.js";import"./dictionary-A4W1xb0R.js";import"./index-DQRW2_Vj.js";export{o as default};
