import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-bL5Dzhqd.js";import"./dictionary-KNv_KSjm.js";import"./index-Bl-hqx7R.js";export{o as default};
