import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CX_FotwB.js";import"./user_customer-DS2rhVP5.js";import"./index-C4dvHyEP.js";import"./apiLoading-Cq5_RQpj.js";export{o as default};
