import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6c0ATAM.js";import"./dictionary-C-zGKNnb.js";import"./index-P8dMXWZ8.js";export{o as default};
