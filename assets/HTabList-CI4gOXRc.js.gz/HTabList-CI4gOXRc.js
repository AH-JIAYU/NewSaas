import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BDb6QaJo.js";import"./index-BzKbJ4XU.js";import"./use-resolve-button-type-UMdQ3pg2.js";export{o as default};
