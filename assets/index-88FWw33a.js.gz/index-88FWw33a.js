import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CNngZJKZ.js";import"./apiLoading-BQ3SK4Mx.js";import"./index-O4wggHBV.js";import"./user_customer-ByPUDGTB.js";export{o as default};
