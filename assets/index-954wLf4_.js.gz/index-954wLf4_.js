import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BX3XClsa.js";import"./survey_vip-Cw9msRyI.js";import"./index-BRLuNibF.js";export{o as default};
