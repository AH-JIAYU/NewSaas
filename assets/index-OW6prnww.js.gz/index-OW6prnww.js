import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cx_bJz3i.js";import"./user_supplier-bauAwdmr.js";import"./index-B9P-dBk8.js";export{o as default};
