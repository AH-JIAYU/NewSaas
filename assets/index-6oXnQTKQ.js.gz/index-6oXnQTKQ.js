import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DQqp1AJQ.js";import"./project_settlement-BRtGDkxu.js";import"./index-imHNa2Ye.js";export{o as default};
