import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BaDaNt4u.js";import"./index-BQdTqJhu.js";export{m as default};
