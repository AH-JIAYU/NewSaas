import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DdCXpCAI.js";import"./index-WSopa337.js";import"./use-resolve-button-type-CgKLkl2z.js";export{o as default};
