import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COCSXnss.js";import"./dictionary-Vo4jz5gX.js";import"./index-DqfN6Hiv.js";export{o as default};
