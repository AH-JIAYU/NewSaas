import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ngFTq-F6.js";import"./index-BEU4aNZB.js";/* empty css                      */export{o as default};
