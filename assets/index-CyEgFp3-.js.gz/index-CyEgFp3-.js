import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cea4LSzD.js";import"./dictionary-3Ph7UWID.js";import"./index-DNJfIwMj.js";export{o as default};
