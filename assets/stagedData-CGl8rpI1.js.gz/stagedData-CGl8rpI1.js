import{E as a,r as e}from"./index-fuY6ctZR.js";const u=a("stagedData",()=>{const t=e(),s=e(),r=e(),o=e();return{userCustomer:t,usersupplier:s,surveyVip:r,surveyVipGroup:o}}),p=u;export{p as u};
