import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C38TN1aT.js";import"./dictionary-53VLGgce.js";import"./index-JYvP5qSa.js";export{o as default};
