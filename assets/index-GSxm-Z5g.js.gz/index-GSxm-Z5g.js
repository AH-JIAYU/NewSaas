import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BWGDnPRh.js";import"./user_customer-Dq3KV6iK.js";import"./index-BODpozrq.js";import"./apiLoading-BGef7Ue2.js";export{o as default};
