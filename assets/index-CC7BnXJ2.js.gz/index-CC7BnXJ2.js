import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BRwGZyh5.js";import"./survey_vip-2aUC3hZY.js";import"./index-Czfzf8F4.js";export{o as default};
