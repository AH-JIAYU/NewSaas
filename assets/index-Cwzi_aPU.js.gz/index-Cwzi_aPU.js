import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-JabkciQx.js";import"./dictionary-DBdkbVwA.js";import"./index-CHlyMxym.js";export{o as default};
