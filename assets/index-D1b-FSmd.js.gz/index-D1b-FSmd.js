import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1UZGRGS.js";import"./dictionary-We9nLD_T.js";import"./index-CXnU28uj.js";export{o as default};
