import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BD5kyEut.js";import"./index-DEFxt4uT.js";/* empty css                      */export{o as default};
