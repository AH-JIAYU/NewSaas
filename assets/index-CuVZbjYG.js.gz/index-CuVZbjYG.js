import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C-RoO65i.js";import"./index-B9G65lgK.js";/* empty css                      */export{o as default};
