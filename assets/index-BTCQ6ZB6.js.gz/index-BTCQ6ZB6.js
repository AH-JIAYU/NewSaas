import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-dnnamdNR.js";import"./finance_invoice-BfK83jaP.js";import"./index-DaerNgvX.js";export{o as default};
