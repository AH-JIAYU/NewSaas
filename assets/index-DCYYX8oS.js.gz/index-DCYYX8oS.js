import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BY7qKfSz.js";import"./survey_vip-DKyE7ojE.js";import"./index-DgaOPsto.js";export{o as default};
