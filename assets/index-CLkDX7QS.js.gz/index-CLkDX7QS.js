import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BTOIerM9.js";import"./index-B4ARIQ4W.js";/* empty css                      */export{o as default};
