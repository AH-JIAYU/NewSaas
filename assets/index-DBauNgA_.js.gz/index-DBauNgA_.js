import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-VvrSgaDq.js";import"./index-DQy_kPaF.js";export{m as default};
