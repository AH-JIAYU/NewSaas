import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Cg0ocsXt.js";import"./index-3-Luvx0C.js";export{m as default};
