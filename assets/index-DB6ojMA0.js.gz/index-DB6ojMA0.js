import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Di1HVF_k.js";import"./projectManagement-DxNiGbbx.js";import"./index-dg3DzOoH.js";export{o as default};
