import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1efcDw6.js";import"./dictionary-Df47rGcy.js";import"./index-C9-fbFy3.js";export{o as default};
