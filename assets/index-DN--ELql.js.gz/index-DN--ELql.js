import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DY0HH_ha.js";import"./position_manage-DzJcptJ-.js";import"./index-Stn8oVZn.js";export{o as default};
