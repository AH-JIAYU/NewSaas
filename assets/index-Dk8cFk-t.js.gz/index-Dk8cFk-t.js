import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B20a68M8.js";import"./dictionary-BW4y_-bG.js";import"./index-BjkRYaBU.js";export{o as default};
