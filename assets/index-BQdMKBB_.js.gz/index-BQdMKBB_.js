import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D1juEHyN.js";import"./project_settlement-DKSU2fym.js";import"./index-DXBclCKb.js";export{o as default};
