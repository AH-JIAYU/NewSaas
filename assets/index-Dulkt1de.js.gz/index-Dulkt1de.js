import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dkhn4s8o.js";import"./index-BaLgkNXx.js";/* empty css                      */export{o as default};
