import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DipP8e6r.js";import"./index-D0we2t1S.js";import"./use-resolve-button-type-BQo_QjcS.js";export{o as default};
