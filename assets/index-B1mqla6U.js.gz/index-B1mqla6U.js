import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DYCrdsR2.js";import"./project_settlement-crOFmDJ4.js";import"./index-Ci7w1hVZ.js";export{o as default};
