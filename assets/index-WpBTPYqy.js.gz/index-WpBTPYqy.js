import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DRe7d-Px.js";import"./user_supplier-BEFK2lAS.js";import"./index-gn7cIfcI.js";export{o as default};
