import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BOes5kEo.js";import"./user_customer-BLpq86t1.js";import"./index-DG8rCAXq.js";import"./apiLoading-322GpSgR.js";export{o as default};
