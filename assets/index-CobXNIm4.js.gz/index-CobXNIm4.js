import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-0DLg5MDo.js";import"./user_customer-Bpp33sSR.js";import"./index-CK7oE2zh.js";import"./apiLoading-C_lzfaAz.js";export{o as default};
