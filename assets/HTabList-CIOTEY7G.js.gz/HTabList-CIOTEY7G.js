import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Pr-SYv1A.js";import"./index-ooHtBFCv.js";import"./use-resolve-button-type-DYzOwwmr.js";export{o as default};
