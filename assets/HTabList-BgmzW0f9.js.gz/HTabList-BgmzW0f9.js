import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CBGJ41sn.js";import"./index-CSGYhle1.js";import"./use-resolve-button-type-DKN-gNII.js";export{o as default};
