import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BCwtPpWI.js";import"./user_customer-ehULdmnU.js";import"./index-6EN4pAdE.js";import"./apiLoading-D0GWlqhi.js";export{o as default};
