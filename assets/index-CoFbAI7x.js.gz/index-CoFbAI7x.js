import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BDPltkpB.js";import"./dictionary-BEZIJ_LQ.js";import"./index-DwfJnMpB.js";export{o as default};
