import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-0qHx3z5N.js";import"./dictionary-CkHc2pjJ.js";import"./index-BFZzm-5X.js";export{o as default};
