import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-7A-RFs0L.js";import"./index-CX2PmK0L.js";export{m as default};
