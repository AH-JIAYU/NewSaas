import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-b0-joIIO.js";import"./index-JlPL0OoL.js";export{m as default};
