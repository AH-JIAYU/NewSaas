import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CAxObCAk.js";import"./project_settlement-B9PL_iPa.js";import"./index-Cv0hhvIB.js";export{o as default};
