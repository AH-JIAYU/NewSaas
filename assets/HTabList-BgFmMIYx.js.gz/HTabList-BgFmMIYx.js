import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DRHS-W1G.js";import"./index-BJV8hziD.js";import"./use-resolve-button-type-CKcvN8qM.js";export{o as default};
