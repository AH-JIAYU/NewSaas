import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BhLSw817.js";import"./projectManagement-BGLAaU-v.js";import"./index-hVAcaXkI.js";export{o as default};
