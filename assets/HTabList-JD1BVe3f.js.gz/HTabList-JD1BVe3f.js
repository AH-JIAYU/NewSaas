import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DG9tCMh0.js";import"./index-BM-MyKGQ.js";import"./use-resolve-button-type-JdGr324C.js";export{o as default};
