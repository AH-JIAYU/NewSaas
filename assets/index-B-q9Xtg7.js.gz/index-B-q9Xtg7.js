import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C9LVoyzT.js";import"./projectManagement-DlPHNKQt.js";import"./index-BWZuMFuC.js";export{o as default};
