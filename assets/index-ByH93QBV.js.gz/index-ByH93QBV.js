import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CgDm4rp7.js";import"./index-BNK2CN6v.js";/* empty css                      */export{o as default};
