import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BBk_9dtS.js";import"./position_manage-D1WEz_75.js";import"./index-Cv0hhvIB.js";export{o as default};
