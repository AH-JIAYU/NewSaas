import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-EP-v7siB.js";import"./index-CbrjSwM7.js";import"./role-Dm2h14yc.js";export{o as default};
