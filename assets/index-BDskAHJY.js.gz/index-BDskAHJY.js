import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D3900ZUT.js";import"./dictionary-f3yosdXy.js";import"./index-BM-MyKGQ.js";export{o as default};
