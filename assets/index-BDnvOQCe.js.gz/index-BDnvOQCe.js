import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDEG-h4Z.js";import"./user_supplier-BeGLRlrF.js";import"./index-CIMs2gPi.js";export{o as default};
