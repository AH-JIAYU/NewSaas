import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DorWwx6p.js";import"./dictionary-DDhXsL_S.js";import"./index-DzqVH_Dc.js";export{o as default};
