import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DlnTIhg5.js";import"./apiLoading-BnL8ZCGb.js";import"./index-Bbqw4ZE_.js";import"./user_customer-D1-9wH2V.js";export{o as default};
