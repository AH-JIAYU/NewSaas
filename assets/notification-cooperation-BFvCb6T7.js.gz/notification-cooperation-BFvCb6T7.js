import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-CLGfFXnY.js";import"./index-BdNuNAfF.js";export{m as default};
