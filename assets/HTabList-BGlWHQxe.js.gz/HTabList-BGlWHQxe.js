import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-zFruUY3Q.js";import"./index-1E3Ahbco.js";import"./use-resolve-button-type-DagWUQuT.js";export{o as default};
