import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CUbzwGi9.js";import"./dictionary-5IQToRQa.js";import"./index-DgaOPsto.js";export{o as default};
