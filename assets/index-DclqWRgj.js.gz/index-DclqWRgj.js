import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ChaBTsh8.js";import"./apiLoading-CscGKk70.js";import"./index-B5L6_y5W.js";import"./user_customer-C87A-Mia.js";export{o as default};
