import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BvVzDjQe.js";import"./dictionary-BIHv9s0k.js";import"./index-BjTEgIZu.js";export{o as default};
