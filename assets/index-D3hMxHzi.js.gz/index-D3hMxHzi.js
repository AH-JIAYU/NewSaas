import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bbd6STul.js";import"./dictionary-BzGIh3A0.js";import"./index-CBBxVEK9.js";export{o as default};
