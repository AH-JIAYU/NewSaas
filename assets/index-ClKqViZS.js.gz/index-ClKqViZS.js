import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BWv_iyAx.js";import"./index-D_G0Q2kt.js";export{m as default};
