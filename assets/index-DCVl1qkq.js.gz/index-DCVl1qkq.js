import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CUgc7yic.js";import"./dictionary-7VquqmQ6.js";import"./index-CFPT1bUN.js";export{o as default};
