import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BkXmhWLL.js";import"./index-D_0r3zo_.js";import"./use-resolve-button-type-_hKoHtjt.js";export{o as default};
