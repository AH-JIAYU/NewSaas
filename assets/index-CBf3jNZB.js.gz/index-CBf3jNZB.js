import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Co17aO85.js";import"./dictionary-CcLfeQGt.js";import"./index-BJV8hziD.js";export{o as default};
