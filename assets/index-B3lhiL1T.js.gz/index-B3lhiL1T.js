import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B0--xemU.js";import"./dictionary-B53CsnW1.js";import"./index-D8xTGeLE.js";export{o as default};
