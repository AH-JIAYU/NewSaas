import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BRNVo04r.js";import"./user_supplier-B-rKhdlC.js";import"./index-DneCj3-6.js";export{o as default};
