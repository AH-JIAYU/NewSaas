import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BW8ictVh.js";import"./index-BOdyVakj.js";import"./index-KptYxjxV.js";export{o as default};
