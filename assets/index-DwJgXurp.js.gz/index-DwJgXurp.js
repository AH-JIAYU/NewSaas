import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CORCNbdE.js";import"./dictionary-FyPwpI5G.js";import"./index-pHZL677A.js";export{o as default};
