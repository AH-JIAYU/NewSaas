import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C6cy-Wl_.js";import"./index-6gzB3T3D.js";/* empty css                      */export{o as default};
