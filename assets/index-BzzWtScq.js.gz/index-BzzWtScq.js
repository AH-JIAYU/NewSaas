import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DA_FrHdS.js";import"./index-oxkd8Woh.js";/* empty css                      */export{o as default};
