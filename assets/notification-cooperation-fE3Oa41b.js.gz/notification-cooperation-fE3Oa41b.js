import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DFkZFmn5.js";import"./index-IO_LN-IO.js";export{m as default};
