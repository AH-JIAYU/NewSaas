import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-zf5hGsBu.js";import"./apiLoading-BjlhBv-U.js";import"./index-DhOXgAfG.js";import"./user_customer-DArXr3El.js";export{o as default};
