import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Buv0o7Hk.js";import"./survey_vip-lD-M43hH.js";import"./index-C9fHoe7f.js";export{o as default};
