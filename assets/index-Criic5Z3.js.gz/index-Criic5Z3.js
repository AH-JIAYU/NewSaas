import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DSYK-q8p.js";import"./survey_vip-CKEz56NZ.js";import"./index-BW4MUnX3.js";export{o as default};
