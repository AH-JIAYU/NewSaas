import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CrSj94AF.js";import"./dictionary-B9gfkoIk.js";import"./index-BN31BxGx.js";export{o as default};
