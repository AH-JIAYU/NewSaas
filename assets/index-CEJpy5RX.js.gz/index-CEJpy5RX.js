import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DnS6F_ge.js";import"./projectManagement-DAV9O4DS.js";import"./index-UIIVoe2v.js";export{o as default};
