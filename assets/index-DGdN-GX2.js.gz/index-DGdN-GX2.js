import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-PqCwUWVk.js";import"./user_supplier-iWqvBdEz.js";import"./index-BKSxisHz.js";export{o as default};
