import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BF6vh-k9.js";import"./index-RYF7mVNB.js";import"./index-B7HNXvov.js";export{o as default};
