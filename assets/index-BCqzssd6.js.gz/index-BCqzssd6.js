import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BT1XhFix.js";import"./apiLoading-B2h5Te4i.js";import"./index-CiUEwP-Q.js";import"./user_customer-D65jykB5.js";export{o as default};
