import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BE9NIcsO.js";import"./apiLoading-BVJnIwKl.js";import"./index-D46Z3f8a.js";import"./user_customer-Gybbltjy.js";export{o as default};
