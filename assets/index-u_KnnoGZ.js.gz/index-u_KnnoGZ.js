import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CaVsUYkL.js";import"./project_settlement-CTRQunja.js";import"./index-D-6WSM-3.js";export{o as default};
