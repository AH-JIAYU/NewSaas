import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BifMsDT6.js";import"./dictionary-CJa4tEip.js";import"./index-BHfIgYzG.js";export{o as default};
