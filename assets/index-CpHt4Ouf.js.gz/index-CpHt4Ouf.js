import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-taAm3Di6.js";import"./index-B9wLryVD.js";/* empty css                      */export{o as default};
