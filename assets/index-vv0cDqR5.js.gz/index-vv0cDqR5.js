import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CNPtNzci.js";import"./dictionary-Dxz4G-j1.js";import"./index-DSaDGYUV.js";export{o as default};
