import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BSnYT9ET.js";import"./index-CxQ2sQpP.js";import"./index-CbX2_yi1.js";export{o as default};
