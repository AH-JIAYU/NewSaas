import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cs1lbm5L.js";import"./user_supplier-BMzS2Tp1.js";import"./index-BOIe6JP6.js";export{o as default};
