import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-C2ojNxej.js";import"./index-Dd_XLnr_.js";export{m as default};
