import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DdqdcFDZ.js";import"./index-WdaD7n5-.js";import"./use-resolve-button-type-C5EW94pQ.js";export{o as default};
