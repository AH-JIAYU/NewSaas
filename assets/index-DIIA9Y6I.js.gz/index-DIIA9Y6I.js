import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D2aiKAop.js";import"./dictionary-BCd-Am--.js";import"./index-CpaKVi3K.js";export{o as default};
