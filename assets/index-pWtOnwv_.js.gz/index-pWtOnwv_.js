import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DapOcP9L.js";import"./dictionary-BZaAJVRy.js";import"./index-C73_aXNI.js";export{o as default};
