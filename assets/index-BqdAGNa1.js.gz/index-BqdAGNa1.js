import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CW2JwmWO.js";import"./dictionary-DC9a0p4m.js";import"./index-B-uIrzK6.js";export{o as default};
