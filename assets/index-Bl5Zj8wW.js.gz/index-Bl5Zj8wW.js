import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D7M83bcp.js";import"./dictionary-qhXcy74M.js";import"./index-CWM9ShDd.js";export{o as default};
