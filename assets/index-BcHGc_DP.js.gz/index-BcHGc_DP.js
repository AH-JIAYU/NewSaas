import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-De_Od10O.js";import"./dictionary-C8zyvWup.js";import"./index-6YYRAA_i.js";export{o as default};
