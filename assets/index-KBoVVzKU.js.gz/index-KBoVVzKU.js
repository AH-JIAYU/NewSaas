import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BQR4mcju.js";import"./apiLoading-9tau8HoF.js";import"./index-CF9jBOb7.js";import"./user_customer-C5uTLuxu.js";export{o as default};
