import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BnzxQEH8.js";import"./index--j4xLQ48.js";export{m as default};
