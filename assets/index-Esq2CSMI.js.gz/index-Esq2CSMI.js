import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DZ0zKgfw.js";import"./user_customer-BVBWfKA4.js";import"./index-QzTLBS9C.js";import"./apiLoading-DOvOeYtT.js";export{o as default};
