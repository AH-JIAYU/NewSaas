import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C4i2A3BR.js";import"./dictionary-DAQhdBXm.js";import"./index-neAswt5j.js";export{o as default};
