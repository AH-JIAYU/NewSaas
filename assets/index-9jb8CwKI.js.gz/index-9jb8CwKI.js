import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B9UlJzTE.js";import"./index-D4axY0XK.js";/* empty css                      */export{o as default};
