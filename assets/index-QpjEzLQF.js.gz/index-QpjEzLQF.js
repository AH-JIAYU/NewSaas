import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CnlNAs7r.js";import"./dictionary-DEq7VMT1.js";import"./index-Dm70kv03.js";export{o as default};
