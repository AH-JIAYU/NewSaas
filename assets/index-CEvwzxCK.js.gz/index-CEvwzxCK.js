import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-j4UXw-1f.js";import"./project_settlement-BN97i3qK.js";import"./index-puGejJ6c.js";export{o as default};
