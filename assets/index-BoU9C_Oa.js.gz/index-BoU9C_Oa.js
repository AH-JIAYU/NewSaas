import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DWxI572O.js";import"./index-B-GmwkKY.js";/* empty css                      */export{o as default};
