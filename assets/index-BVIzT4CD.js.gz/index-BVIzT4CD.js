import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BH_kDjRi.js";import"./position_manage-IkW2ic_S.js";import"./index-BsetXtVy.js";export{o as default};
