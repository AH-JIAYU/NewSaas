import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BIV-DCC5.js";import"./dictionary-BAgv_9AD.js";import"./index-DgghPrSk.js";export{o as default};
