import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B8QKJAER.js";import"./index-DrKhIxfR.js";export{m as default};
