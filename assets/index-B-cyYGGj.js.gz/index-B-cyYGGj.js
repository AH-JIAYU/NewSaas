import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-QbohA-nI.js";import"./index-Bil3zl1I.js";export{m as default};
