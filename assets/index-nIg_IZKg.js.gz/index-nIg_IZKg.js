import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DIgScvwx.js";import"./project_settlement-aYRXCDLR.js";import"./index-68hOHSHJ.js";export{o as default};
