import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BREFrTW6.js";import"./index-yv3hHHZ6.js";export{m as default};
