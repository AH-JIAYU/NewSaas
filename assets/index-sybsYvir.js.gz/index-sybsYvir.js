import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DNiO-apN.js";import"./projectManagement-CIb_MWsi.js";import"./index-rEB4CdRn.js";export{o as default};
