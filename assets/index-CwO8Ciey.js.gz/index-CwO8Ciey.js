import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DFNB9Gnt.js";import"./index-BE57dBdt.js";export{m as default};
