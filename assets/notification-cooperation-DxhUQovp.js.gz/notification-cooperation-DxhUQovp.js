import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DXvgw6CZ.js";import"./index-CUMm1uz-.js";export{m as default};
