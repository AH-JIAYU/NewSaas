import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DD6yUiDp.js";import"./index-Cy3Ir7tY.js";import"./use-resolve-button-type-BuQ3ooNl.js";export{o as default};
