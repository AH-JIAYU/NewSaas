import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BIgNd-Rc.js";import"./user_cooperation-CwM3eI4S.js";import"./index-CTDaT2Z5.js";export{o as default};
