import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CjAts3Kr.js";import"./dictionary-DAo05N-L.js";import"./index-CfmU-pu3.js";export{o as default};
