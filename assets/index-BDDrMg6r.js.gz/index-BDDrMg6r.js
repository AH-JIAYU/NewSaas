import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Cxx3tZeR.js";import"./index-CQrZNnCa.js";export{m as default};
