import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DrZ2Y_yy.js";import"./index-tHSAnviy.js";export{m as default};
