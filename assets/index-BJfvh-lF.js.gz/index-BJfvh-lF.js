import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-7JIzXcB2.js";import"./index-Bf0tJ0Rs.js";/* empty css                      */export{o as default};
