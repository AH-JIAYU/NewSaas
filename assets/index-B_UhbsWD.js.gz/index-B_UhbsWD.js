import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-COs5Xjnf.js";import"./index-CF4EWO8e.js";import"./index-lJjzSOFx.js";import"./department-C-kmiD1c.js";export{o as default};
