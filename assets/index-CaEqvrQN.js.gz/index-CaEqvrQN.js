import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CXluiein.js";import"./index-BTA1u_t0.js";export{m as default};
