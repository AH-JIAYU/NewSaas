import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B1of1gGo.js";import"./dictionary-DITa3g75.js";import"./index-C2gY24yx.js";export{o as default};
