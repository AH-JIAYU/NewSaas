import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bwula7t6.js";import"./projectManagement-CAJVNzl-.js";import"./index-C6aesvjM.js";export{o as default};
