import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DTIw3FXR.js";import"./user_cooperation-KDc-aY8Y.js";import"./index-COAhu-td.js";export{o as default};
