import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bob-9UI6.js";import"./dictionary-sOwZI-jM.js";import"./index-DOty51pI.js";export{o as default};
