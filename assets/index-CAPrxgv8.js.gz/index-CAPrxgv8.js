import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CFjgIjft.js";import"./project_settlement--ii7ocpt.js";import"./index-ClKnHj-s.js";export{o as default};
