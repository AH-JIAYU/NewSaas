import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C4JBHmqp.js";import"./project_settlement-B15rB65W.js";import"./index-C-YnF30x.js";export{o as default};
