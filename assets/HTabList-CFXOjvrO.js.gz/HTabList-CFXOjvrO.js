import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-Dj1dPFgz.js";import"./index-0kgWkY4k.js";import"./use-resolve-button-type-N0tMQWwp.js";export{o as default};
