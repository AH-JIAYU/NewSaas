import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-IKYHXOBA.js";import"./index-BdHtZquS.js";/* empty css                      */export{o as default};
