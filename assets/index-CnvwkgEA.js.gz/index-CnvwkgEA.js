import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-nEc9v72l.js";import"./index-DaCw3jny.js";export{m as default};
