import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C7xFPLxW.js";import"./dictionary-BwdnQ8a0.js";import"./index-C41NkH8z.js";export{o as default};
