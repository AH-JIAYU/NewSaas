import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Cflp5Gs4.js";import"./finance_invoice-NZS9gYgm.js";import"./index-CIFOFIw0.js";export{o as default};
