import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-pmPUE9OJ.js";import"./index-CR_Og9_c.js";export{m as default};
