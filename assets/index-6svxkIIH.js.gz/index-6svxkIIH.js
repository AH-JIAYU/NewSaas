import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZHQYVu-.js";import"./user_customer-wNELsEL0.js";import"./index-BbVMI3d4.js";import"./apiLoading-SxkeGbtU.js";export{o as default};
