import{_ as o}from"./HToggle.vue_vue_type_script_setup_true_lang-dX6j0Jlw.js";import"./index-CWNW1mmx.js";import"./use-resolve-button-type-DF3TTB-F.js";export{o as default};
