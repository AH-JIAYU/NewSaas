import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-De4_nWYf.js";import"./user_customer-tDYWgoqe.js";import"./index-UMFAIpvB.js";import"./apiLoading-C1KmmSA6.js";export{o as default};
