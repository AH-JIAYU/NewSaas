import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-GnaTFwCB.js";import"./dictionary-B0ZMnQ0Q.js";import"./index-BuCeI957.js";export{o as default};
