import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C4BaPUt2.js";import"./dictionary-Cfw5Fvzj.js";import"./index-AlQFjtA_.js";export{o as default};
