import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Du8gRiB2.js";import"./index-Bh_VDJMf.js";/* empty css                      */export{o as default};
