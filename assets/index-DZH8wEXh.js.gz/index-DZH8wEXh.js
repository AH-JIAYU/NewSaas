import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DaVrv0gw.js";import"./dictionary-D_423E_t.js";import"./index-CkoP-l3x.js";export{o as default};
