import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-R4E-dkPj.js";import"./dictionary-D6KS3E-6.js";import"./index-BW4MUnX3.js";export{o as default};
