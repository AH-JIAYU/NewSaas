import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BW253VUt.js";import"./dictionary-DxRGWORd.js";import"./index-CZn-RBhq.js";export{o as default};
