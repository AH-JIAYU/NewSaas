import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CFv6U8KJ.js";import"./index-DtqcPD5G.js";/* empty css                      */export{o as default};
