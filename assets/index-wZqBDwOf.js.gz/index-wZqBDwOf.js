import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-2zpbblsT.js";import"./dictionary-CFHH3Fsw.js";import"./index-DRY8n3bv.js";export{o as default};
