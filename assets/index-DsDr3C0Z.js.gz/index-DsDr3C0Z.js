import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-fVC9Avyo.js";import"./index-kcZ6WDso.js";export{m as default};
