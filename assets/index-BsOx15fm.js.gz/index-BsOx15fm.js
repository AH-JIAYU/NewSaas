import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D-v7-U7n.js";import"./dictionary-CmSOQ7Kk.js";import"./index-C29iptdf.js";export{o as default};
