import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DXCPNWX2.js";import"./dictionary-IHvr2M4a.js";import"./index-7bVKZbtb.js";export{o as default};
