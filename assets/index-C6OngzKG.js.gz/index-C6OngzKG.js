import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BqcS5kWh.js";import"./index-LooN7LAT.js";import"./role-Dtm9gzEe.js";export{o as default};
