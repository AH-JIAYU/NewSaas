import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D9eOZ2FP.js";import"./dictionary-0-_c24cD.js";import"./index-DU62AkNh.js";export{o as default};
