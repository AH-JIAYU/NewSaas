import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-P1v24I8p.js";import"./position_manage-CJBwwrSK.js";import"./index-Ci6VJ9pE.js";export{o as default};
