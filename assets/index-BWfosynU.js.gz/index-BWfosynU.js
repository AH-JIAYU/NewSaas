import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CWm6yl-h.js";import"./index-BNpMTd1y.js";import"./index-CWNW1mmx.js";export{o as default};
