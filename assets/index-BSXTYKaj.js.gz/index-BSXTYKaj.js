import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-qzWqPtO4.js";import"./dictionary-B3xqSMya.js";import"./index-BUdUbmhT.js";export{o as default};
