import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BOZpPsOh.js";import"./position_manage-Du_NXAbk.js";import"./index-0OvYWKzQ.js";export{o as default};
