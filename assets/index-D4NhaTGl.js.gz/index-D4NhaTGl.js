import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DfLHvkCg.js";import"./index-D8X23OCv.js";import"./index-68hOHSHJ.js";import"./department-BpHYkcG7.js";export{o as default};
