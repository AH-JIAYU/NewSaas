import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bzzdo5Xd.js";import"./index-BSVPXFpA.js";/* empty css                      */export{o as default};
