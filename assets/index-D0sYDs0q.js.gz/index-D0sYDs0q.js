import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_40jlCc.js";import"./dictionary-DwMHVm9-.js";import"./index-Bgpn2lkb.js";export{o as default};
