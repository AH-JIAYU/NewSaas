import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DB1-hSfB.js";import"./user_cooperation-DnYGmLR3.js";import"./index-BL8qUovB.js";export{o as default};
