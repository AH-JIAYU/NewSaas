import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DFUT2_Pr.js";import"./index-DSaDGYUV.js";/* empty css                      */export{o as default};
