import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B1HvP27f.js";import"./dictionary-CaGqEWSL.js";import"./index-SEhFNywK.js";export{o as default};
