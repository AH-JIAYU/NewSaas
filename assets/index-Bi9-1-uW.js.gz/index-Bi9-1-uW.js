import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DpS8_E7o.js";import"./dictionary-CaK4Ze2H.js";import"./index-F2qHMxN5.js";export{o as default};
