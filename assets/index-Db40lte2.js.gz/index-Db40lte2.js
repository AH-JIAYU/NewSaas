import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C43ZIQoH.js";import"./index-DXIwLSJH.js";/* empty css                      */export{o as default};
