import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ks4jca-B.js";import"./user_customer-BrPXG7Wg.js";import"./index-DmgRXF6j.js";import"./apiLoading-B34wibx-.js";export{o as default};
