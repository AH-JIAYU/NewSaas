import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-DwvP-5O2.js";import"./index-DaerNgvX.js";export{m as default};
