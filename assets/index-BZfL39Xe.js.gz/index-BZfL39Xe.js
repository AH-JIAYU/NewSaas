import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BawtUfaW.js";import"./dictionary-DwrZW5eQ.js";import"./index-Bbqw4ZE_.js";export{o as default};
