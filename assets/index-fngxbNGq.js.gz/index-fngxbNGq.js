import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-JO4qxMyh.js";import"./dictionary-BauUld7V.js";import"./index-D7ktWcYH.js";export{o as default};
