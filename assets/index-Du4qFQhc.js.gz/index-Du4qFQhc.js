import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BABj51mK.js";import"./index-C32xF_ni.js";import"./role-CSeaF52X.js";export{o as default};
