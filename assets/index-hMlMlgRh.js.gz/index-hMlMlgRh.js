import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-NI0pRzx7.js";import"./dictionary-B-0d294U.js";import"./index-BKVONNyH.js";export{o as default};
