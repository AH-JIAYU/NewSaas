import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CEMej_pl.js";import"./position_manage-DF4swZJ1.js";import"./index-BpCZv0AG.js";export{o as default};
