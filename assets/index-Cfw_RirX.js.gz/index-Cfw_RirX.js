import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DY_n1Fs7.js";import"./projectManagement-B_Be8Wov.js";import"./index-DK9KDSNt.js";export{o as default};
