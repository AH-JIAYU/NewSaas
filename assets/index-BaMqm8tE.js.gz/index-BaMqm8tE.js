import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BAewfWn-.js";import"./user_customer-Bm9pAk5B.js";import"./index-B9G65lgK.js";import"./apiLoading-BB74-exq.js";export{o as default};
