import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C48FKQtF.js";import"./dictionary-CYxQLK8n.js";import"./index-Dp-ZPQFq.js";export{o as default};
