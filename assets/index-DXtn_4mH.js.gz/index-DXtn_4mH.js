import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B3O6qcbE.js";import"./apiLoading-DmwGIXfZ.js";import"./index-DAPnvqq4.js";import"./user_customer-C8fXw4px.js";export{o as default};
