import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BI6T4oxY.js";import"./dictionary-Cn-Dan9M.js";import"./index-wfZ6lyFc.js";export{o as default};
