import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-GUpQyYC4.js";import"./projectManagement-CUG2K98N.js";import"./index-Caan35Ad.js";export{o as default};
