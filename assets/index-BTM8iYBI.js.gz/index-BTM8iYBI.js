import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-JwA_w52_.js";import"./dictionary-C8NpU3_e.js";import"./index-Dy4b05tF.js";export{o as default};
