import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BxrKyXUr.js";import"./dictionary-6z_l7vHE.js";import"./index-DiNXpavG.js";export{o as default};
