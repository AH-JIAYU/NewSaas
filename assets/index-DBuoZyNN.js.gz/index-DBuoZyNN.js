import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CkBP_usJ.js";import"./dictionary-B9NnS_Ib.js";import"./index-BkYGZ8kq.js";export{o as default};
