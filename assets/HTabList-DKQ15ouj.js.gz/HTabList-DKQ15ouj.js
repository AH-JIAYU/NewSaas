import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BDJ-KLEk.js";import"./index-BOIe6JP6.js";import"./use-resolve-button-type-OIM-Jyuu.js";export{o as default};
