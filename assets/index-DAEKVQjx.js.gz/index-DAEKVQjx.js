import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-pLTrhKyb.js";import"./survey_vip-C3i0tH1y.js";import"./index-Bla6RIPe.js";export{o as default};
