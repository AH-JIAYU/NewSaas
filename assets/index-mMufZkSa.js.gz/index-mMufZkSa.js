import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1bfQS4h.js";import"./index-CHTO5iG0.js";/* empty css                      */export{o as default};
