import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BibxK1ta.js";import"./index-D5onk9Ca.js";export{m as default};
