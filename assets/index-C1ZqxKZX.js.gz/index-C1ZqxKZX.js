import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CUD_CMVC.js";import"./index-DzccDyec.js";export{m as default};
