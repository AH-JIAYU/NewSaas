import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3jz1mpz.js";import"./user_supplier-D_Rrud0-.js";import"./index-BoPGNH9M.js";export{o as default};
