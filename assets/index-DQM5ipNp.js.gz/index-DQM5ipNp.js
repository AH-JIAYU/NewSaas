import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-RtWCyvby.js";import"./dictionary-B25JZ1ka.js";import"./index-CV_e-tAb.js";export{o as default};
