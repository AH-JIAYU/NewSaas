import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dj2FTSWG.js";import"./dictionary-DOgyCVN6.js";import"./index-CAqsVIP2.js";export{o as default};
