import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-dFcP_3FM.js";import"./dictionary-CA61E8aQ.js";import"./index-C9NBz-v9.js";export{o as default};
