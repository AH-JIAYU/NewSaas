import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DDtrdHoa.js";import"./user_supplier-WwX5-pe6.js";import"./index-C60j2paH.js";export{o as default};
