import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BcjoJR3Y.js";import"./user_supplier-Cvrm-6Lp.js";import"./index-DiNXpavG.js";export{o as default};
