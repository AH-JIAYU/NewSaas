import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CSjn_sSn.js";import"./index-DXBclCKb.js";export{m as default};
