import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bvs7v_Mn.js";import"./dictionary-DLITStvS.js";import"./index-ZCXpFWW9.js";export{o as default};
