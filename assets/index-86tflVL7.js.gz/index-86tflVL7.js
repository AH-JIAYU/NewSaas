import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CuuqvrMx.js";import"./dictionary-FReD-3d4.js";import"./index-DoiK1_dJ.js";export{o as default};
