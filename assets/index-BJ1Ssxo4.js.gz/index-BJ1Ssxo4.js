import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CkOPbjP_.js";import"./dictionary-D1rXThzy.js";import"./index-BG_Y5tap.js";export{o as default};
