import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-gX4wkEio.js";import"./dictionary-wjIzdGSF.js";import"./index-CN3B1iWi.js";export{o as default};
