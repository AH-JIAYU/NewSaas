import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DaGOWd9a.js";import"./index-BjkRYaBU.js";import"./use-resolve-button-type-C2bu9CBA.js";export{o as default};
