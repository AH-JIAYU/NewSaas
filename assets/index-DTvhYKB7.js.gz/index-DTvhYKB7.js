import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BzcvfrIP.js";import"./index-AMUerYFu.js";import"./index-fMk7yAtp.js";export{o as default};
