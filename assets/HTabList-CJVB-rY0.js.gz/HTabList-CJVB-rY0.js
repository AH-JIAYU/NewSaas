import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DEJH8i3K.js";import"./index-wKxuI42m.js";import"./use-resolve-button-type-FL32xIbV.js";export{o as default};
