import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DexCap8j.js";import"./index-DmgRXF6j.js";export{m as default};
