import{_ as o}from"./index.vue_vue_type_script_setup_true_lang--wxNRFZH.js";import"./dictionary-C9JI5B-w.js";import"./index-gkVyJmAv.js";export{o as default};
