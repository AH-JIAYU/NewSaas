import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-HOVcNuN8.js";import"./dictionary-CTqg560r.js";import"./index-DFSHcGOF.js";export{o as default};
