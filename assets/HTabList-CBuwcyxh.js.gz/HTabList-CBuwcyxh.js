import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-h4iKHsMj.js";import"./index-Dd_XLnr_.js";import"./use-resolve-button-type-DR7ZQR3z.js";export{o as default};
