import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BCnhtGdt.js";import"./index-Caan35Ad.js";export{m as default};
