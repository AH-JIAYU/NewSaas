import{_ as m}from"./notification-cooperation.vue_vue_type_script_setup_true_lang-DN3TzXYt.js";import"./index-DZV01Nt9.js";export{m as default};
