import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-OfaOgE5U.js";import"./dictionary-BtOTOXpK.js";import"./index-D0u_a5jY.js";export{o as default};
